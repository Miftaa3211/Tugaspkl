# xcodehoster

Xcodehoster 2025 - v11.0 for Ubuntu Server 24.04 LTS
--------------------
![alt text](http://xcode.or.id/04_small-logo.png)

Xcodehoster adalah program hosting yang dirancang khusus untuk Ubuntu Server 24.04 yang merupakan produk dari X-code (PT. Teknologi Server Indonesia).
Xcodehoster ini menggunakan PHP 8.3. Untuk implementasinya di https://xcodehoster.com.

File manager
------------
File manager yang digunakan adalah Tiny File Manager dengan sumber dari https://github.com/prasathmani/tinyfilemanager

Cara menggunakan
----------------
1. git clone https://github.com/kurniawandata/xcodehosterv11
2. cd xcodehoster
3. ./instal1

Program ini telah diimplementasikan
-------------------------------
Anda bisa mengakses website xcodehoster di https://xcodehoster.com

Video tutorial untuk v11
----------------
Video tutorial : https://www.youtube.com/watch?v=lptpKA0kEf0

Licensi
-------
GNU General Public License v3

Program ini dibuat oleh :
--------------------------------------------
Kurniawan. E-mail : admin@xcodetraining.com

https://xcode.or.id, https://xcode.co.id, https://xcodetraining.com

