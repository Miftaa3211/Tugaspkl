<?php
/**
 * Xcodehoster v11 - Installer CLI (PHP)
 * Programmer : Kurniawan. kurniawanajazenfone@gmail.com. xcode.or.id.
 * X-code Media - xcode.or.id / xcode.co.id
 *
 * Cara pakai: sudo php install.php
 * (harus dijalankan dari dalam folder xcodehosterv11)
 */

// Pastikan dijalankan dari CLI
if (php_sapi_name() !== 'cli') {
    die("File ini hanya boleh dijalankan dari terminal.\nCara: sudo php install.php\n");
}

// Pastikan dijalankan sebagai root
if (posix_getuid() !== 0) {
    die("Harus dijalankan dengan sudo.\nCara: sudo php install.php\n");
}

echo "Xcodehoster v11 - 6 Oktober 2025\n";

// Cek Ubuntu 24.04
$version = trim(shell_exec("lsb_release -r | awk '{print $2}'"));
if ($version !== '24.04') {
    die("Aplikasi ini tidak mendukung distro Linux Anda, atau Anda menggunakan Ubuntu tapi versinya tidak sesuai. Install pada ubuntu versi 24.04\n");
}

echo "Versi Ubuntu anda didukung oleh aplikasi ini, Ubuntu $version\n";

// Helper functions
function tanya(string $pertanyaan): string {
    echo $pertanyaan;
    return trim(fgets(STDIN));
}

function jalankan(string $cmd): void {
    system($cmd);
}

// Update & install paket
jalankan("apt-get update");
jalankan("apt -y install software-properties-common");
jalankan("apt install apache2");
jalankan("apt install php");
jalankan("cp support/phpinfo.php /var/www/html");
jalankan("apt install mysql-server");

$ipserver = tanya("Masukkan ip publik server : ");
$passwordmysql = tanya("Masukkan password root yang akan dibuat : ");

jalankan("mysql -e \"ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '$passwordmysql';\"");
jalankan("apt install phpmyadmin");
jalankan("apt-get install zip unzip php-zip");
jalankan("a2enmod ssl");
jalankan("service apache2 restart");

jalankan("cp /etc/apache2/apache2.conf backup");
jalankan("cp support/apache2.conf /etc/apache2/");

$domain = tanya("Masukkan nama domain : ");

jalankan("sed -i \"s/xcodehoster.com/$domain/g\" support/subdomain.conf");
jalankan("sed -i \"s/sample.xcodehoster.com/$domain/g\" support/domain.conf");

jalankan("cp /etc/php/8.3/apache2/php.ini /etc/php/8.3/apache2/phpini.backup");
jalankan("cp support/php.ini /etc/php/8.3/apache2");

jalankan("mkdir /home/root");
jalankan("touch /home/root/locked");
jalankan("mkdir /home/pma");
jalankan("touch /home/pma/locked");
jalankan("mkdir /home/www");
jalankan("touch /home/www/locked");
jalankan("mkdir /home/datauser");
jalankan("touch /home/datauser");
jalankan("mkdir /home/xcodehoster");
jalankan("touch /home/datauser/locked");
jalankan("mkdir /home/datapengguna");
jalankan("touch /home/datapengguna/locked");
jalankan("mkdir /home/domain");
jalankan("touch /home/domain/locked");
jalankan("mkdir /home/checkdata");
jalankan("touch /home/checkdata/locked");
jalankan("mkdir /home/checkdata2");
jalankan("touch /home/checkdata2/locked");

jalankan("chmod 777 /home/datauser");
jalankan("cp -r filemanager /home/filemanager");
jalankan("chmod -R 777 /home");
jalankan("a2enmod cgi");
jalankan("chmod 777 /usr/lib/cgi-bin");
jalankan("chmod 777 /usr/lib/cgi-bin/*");
jalankan("chmod 777 /home");
jalankan("chmod 777 /etc/apache2/sites-available");
jalankan("sed -i \"/more/i\\www-data ALL=(ALL) NOPASSWD: ALL\" /etc/sudoers");
jalankan("a2enmod ssl");
jalankan("mkdir /etc/apache2/ssl");
jalankan("chmod 777 /etc/apache2/ssl");
jalankan("apt install jq");
jalankan("apt install imagemagick");

$passwordFlag = "-p$passwordmysql";
jalankan("sed -i \"s/-ppasswordmysql/$passwordFlag/g\" support/run.cgi");
jalankan("sed -i \"s/xcodehoster.com/$domain/g\" support/formdata.cgi");
jalankan("sed -i \"s/xcodehoster.com/$domain/g\" support/run.cgi");
jalankan("sed -i \"s/xcodehoster.com/$domain/g\" support/aktivasi3.cgi");
jalankan("sed -i \"s/xcodehoster.com/$domain/g\" /home/filemanager/index.html");
jalankan("sed -i \"s/xcodehoster.com.pem/$domain.pem/g\" support/subdomain.conf");
jalankan("sed -i \"s/xcodehoster.com.key/$domain.key/g\" support/subdomain.conf");
jalankan("sed -i \"s/xcodehoster.com.pem/$domain.pem/g\" support/domain.conf");
jalankan("sed -i \"s/xcodehoster.com/$domain/g\" support/index.html");
jalankan("sed -i \"s/-ppasswordmysql/$passwordFlag/g\" support/run.cgi");

jalankan("cp support/formfree.cgi /usr/lib/cgi-bin");
jalankan("cp support/run.cgi /usr/lib/cgi-bin");
jalankan("cp support/aktivasi3.cgi /usr/lib/cgi-bin");
jalankan("cp support/formdata.cgi /usr/lib/cgi-bin");
jalankan("cp support/acak.txt /usr/lib/cgi-bin");
jalankan("touch /usr/lib/cgi-bin/vouchers.txt");
jalankan("chmod 777 /usr/lib/cgi-bin/acak.txt");

jalankan("cp support/domain.conf /home/xcodehoster");
jalankan("cp support/domain2.conf /home/xcodehoster");
jalankan("cp support/subdomain.conf /home/xcodehoster");
jalankan("cp support/index.html /home/xcodehoster");
jalankan("cp support/bootstrap.min.css /home/xcodehoster");
jalankan("cp support/hosting.jpg /home/xcodehoster");
jalankan("cp support/xcodehoster21x.png /home/xcodehoster");
jalankan("cp support/coverxcodehoster.png /home/xcodehoster");

jalankan("mkdir /etc/apache2/ssl");
jalankan("touch /etc/apache2/ssl/$domain.pem");
jalankan("touch /etc/apache2/ssl/$domain.key");

jalankan("cp /var/www/html/index.html /var/www/html/backup1.html");
jalankan("cp /home/xcodehoster/* /var/www/html");
jalankan("service apache2 restart");

jalankan("cp support/domain.conf /etc/apache2/sites-available/$domain.conf");
jalankan("sed -i \"s/sample.$domain/$domain/g\" /etc/apache2/sites-available/$domain.conf");
jalankan("sed -i \"s/sample/xcodehoster/g\" /etc/apache2/sites-available/$domain.conf");
jalankan("sed -i \"s/xcodehoster.com.pem/$domain.pem/g\" /etc/apache2/sites-available/$domain.conf");
jalankan("sed -i \"s/xcodehoster.com.key/$domain.key/g\" /etc/apache2/sites-available/$domain.conf");

// Buka nano untuk input SSL certificate (sama seperti bash asli)
jalankan("nano /etc/apache2/ssl/$domain.pem");
jalankan("nano /etc/apache2/ssl/$domain.key");

jalankan("a2ensite $domain.conf");

// Generate 1000 voucher
jalankan("for i in \$(seq 1 1000); do < /dev/urandom tr -dc 'A-Za-z0-9' | head -c 8; echo; done > /usr/lib/cgi-bin/vouchers.txt");

jalankan("sed -i \"s/domain/$domain/g\" /usr/lib/cgi-bin/aktivasi3.cgi");

$zoneid = tanya("Masukkan Zone ID cloudflare : ");
jalankan("sed -i \"s/zoneid/$zoneid/g\" support/aktivasi3.cgi");
jalankan("sed -i \"s/zoneid/$zoneid/g\" /usr/lib/cgi-bin/aktivasi3.cgi");

$email = tanya("Masukkan e-mail cloudflare : ");
jalankan("sed -i \"s/email/$email/g\" support/aktivasi3.cgi");
jalankan("sed -i \"s/email/$email/g\" /usr/lib/cgi-bin/aktivasi3.cgi");

$globalapikey = tanya("Masukkan Global API Key cloudflare : ");
jalankan("sed -i \"s/globalapikey/$globalapikey/g\" support/aktivasi3.cgi");
jalankan("sed -i \"s/globalapikey/$globalapikey/g\" /usr/lib/cgi-bin/aktivasi3.cgi");

$ipserver2 = tanya("Masukkan ip publik server : ");
file_put_contents('/usr/lib/cgi-bin/ip.txt', $ipserver2 . "\n");
jalankan("sed -i \"s/ipserver/$ipserver2/g\" support/aktivasi3.cgi");
jalankan("sed -i \"s/ipserver/$ipserver2/g\" /usr/lib/cgi-bin/aktivasi3.cgi");

// Generate ulang voucher & copy dengan nama random
jalankan("for i in \$(seq 1 1000); do < /dev/urandom tr -dc 'A-Za-z0-9' | head -c 8; echo; done > /usr/lib/cgi-bin/vouchers.txt");
$random_number = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
jalankan("cp /usr/lib/cgi-bin/vouchers.txt /home/xcodehoster/vouchers{$random_number}.txt");

echo "https://$domain/vouchers{$random_number}.txt\n";
jalankan("service apache2 restart");
echo "Instalasi selesai, untuk pengujian silahkan web hosting diakses di alamat $domain\n";
echo "Alamat website: https://$domain/vouchers{$random_number}.txt\n";
