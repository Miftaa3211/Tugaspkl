<?php
/**
 * Xcodehoster v11 - Web Installer (install.php)
 * Programmer : Kurniawan. kurniawanajazenfone@gmail.com. xcode.or.id.
 * X-code Media - xcode.or.id / xcode.co.id
 *
 * Urutan langkah identik dengan bash script "install"
 */

define('LOCK_FILE', __DIR__ . '/.installed');
define('LOG_FILE',  __DIR__ . '/install.log');

session_start();

function logMsg(string $msg): void {
    file_put_contents(LOG_FILE, date('[Y-m-d H:i:s] ') . $msg . "\n", FILE_APPEND);
}

function cmd(string $c): array {
    exec($c . ' 2>&1', $out, $code);
    $str = implode("\n", $out);
    logMsg("CMD [$code]: $c => $str");
    return ['out' => $str, 'code' => $code];
}

function sedFile(string $file, string $from, string $to): void {
    if (!file_exists($file)) return;
    file_put_contents($file, str_replace($from, $to, file_get_contents($file)));
}

function mkdirLocked(string $dir): void {
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    touch("$dir/locked");
}

function generateVouchers(int $n = 1000): string {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $list  = [];
    for ($i = 0; $i < $n; $i++) {
        $v = '';
        for ($j = 0; $j < 8; $j++) $v .= $chars[random_int(0, 61)];
        $list[] = $v;
    }
    return implode("\n", $list);
}

// ── AJAX handler ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    // ── start: simpan form data ──
    if ($_POST['action'] === 'start') {
        // Cek Ubuntu 24.04
        $ver = trim(shell_exec("lsb_release -r 2>/dev/null | awk '{print $2}'"));
        if ($ver !== '24.04') {
            echo json_encode(['ok' => false, 'error' => "Ubuntu $ver tidak didukung. Gunakan Ubuntu 24.04 LTS."]);
            exit;
        }
        $_SESSION['d'] = [
            'ip'       => trim($_POST['ip']       ?? ''),
            'password' => trim($_POST['password'] ?? ''),
            'domain'   => trim($_POST['domain']   ?? ''),
            'zoneid'   => trim($_POST['zoneid']   ?? ''),
            'email'    => trim($_POST['email']    ?? ''),
            'apikey'   => trim($_POST['apikey']   ?? ''),
            'pem'      => trim($_POST['pem']      ?? ''),
            'key'      => trim($_POST['key']      ?? ''),
        ];
        $_SESSION['step'] = 0;
        echo json_encode(['ok' => true]);
        exit;
    }

    // ── step: jalankan satu langkah ──
    if ($_POST['action'] === 'step') {
        $d      = $_SESSION['d']    ?? [];
        $step   = $_SESSION['step'] ?? 0;

        $ip       = $d['ip'];
        $password = $d['password'];
        $domain   = $d['domain'];
        $zoneid   = $d['zoneid'];
        $email    = $d['email'];
        $apikey   = $d['apikey'];
        $pem      = $d['pem'];
        $key      = $d['key'];
        $pwParam  = "-p$password";
        $base     = __DIR__;

        /* ============================================================
           STEPS — urutan PERSIS sama dengan bash "install"
           ============================================================ */
        $steps = [

            // 1. apt-get update
            ['label' => 'apt-get update', 'fn' => function() {
                $r = cmd('apt-get update');
                return $r['code'] === 0;
            }],

            // 2. install software-properties-common
            ['label' => 'Install software-properties-common', 'fn' => function() {
                $r = cmd('apt -y install software-properties-common');
                return $r['code'] === 0;
            }],

            // 3. install apache2
            ['label' => 'Install Apache2', 'fn' => function() {
                $r = cmd('apt -y install apache2');
                return $r['code'] === 0;
            }],

            // 4. install php
            ['label' => 'Install PHP', 'fn' => function() {
                $r = cmd('apt -y install php libapache2-mod-php');
                return $r['code'] === 0;
            }],

            // 5. copy phpinfo.php
            ['label' => 'Copy phpinfo.php ke /var/www/html', 'fn' => function() use ($base) {
                if (file_exists("$base/support/phpinfo.php"))
                    copy("$base/support/phpinfo.php", '/var/www/html/phpinfo.php');
                return true;
            }],

            // 6. install mysql-server
            ['label' => 'Install MySQL Server', 'fn' => function() {
                $r = cmd('apt -y install mysql-server');
                return $r['code'] === 0;
            }],

            // 7. set mysql root password
            ['label' => 'Set password root MySQL', 'fn' => function() use ($password) {
                $esc = addslashes($password);
                $r   = cmd("mysql -e \"ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '$esc';\"");
                logMsg('mysql set password: ' . $r['out']);
                return true; // lanjut meski error (mungkin sudah di-set)
            }],

            // 8. install phpmyadmin
            ['label' => 'Install phpMyAdmin', 'fn' => function() {
                cmd('echo "phpmyadmin phpmyadmin/dbconfig-install boolean true" | debconf-set-selections');
                cmd('echo "phpmyadmin phpmyadmin/app-password-confirm password " | debconf-set-selections');
                cmd('echo "phpmyadmin phpmyadmin/mysql/admin-pass password " | debconf-set-selections');
                cmd('echo "phpmyadmin phpmyadmin/mysql/app-pass password " | debconf-set-selections');
                cmd('echo "phpmyadmin phpmyadmin/reconfigure-webserver multiselect apache2" | debconf-set-selections');
                $r = cmd('DEBIAN_FRONTEND=noninteractive apt -y install phpmyadmin');
                return $r['code'] === 0;
            }],

            // 9. install zip unzip php-zip
            ['label' => 'Install zip, unzip, php-zip, jq, imagemagick', 'fn' => function() {
                $r = cmd('apt -y install zip unzip php-zip jq imagemagick');
                return $r['code'] === 0;
            }],

            // 10. a2enmod ssl, restart apache
            ['label' => 'Aktifkan modul SSL Apache & restart', 'fn' => function() {
                cmd('a2enmod ssl');
                cmd('service apache2 restart');
                return true;
            }],

            // 11. backup & copy apache2.conf
            ['label' => 'Backup & copy apache2.conf', 'fn' => function() use ($base) {
                cmd('cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.backup');
                if (file_exists("$base/support/apache2.conf"))
                    cmd("cp $base/support/apache2.conf /etc/apache2/");
                return true;
            }],

            // 12. sed domain di subdomain.conf & domain.conf
            ['label' => 'Konfigurasi subdomain.conf & domain.conf', 'fn' => function() use ($base, $domain) {
                sedFile("$base/support/subdomain.conf", 'xcodehoster.com', $domain);
                sedFile("$base/support/domain.conf",    'sample.xcodehoster.com', $domain);
                return true;
            }],

            // 13. backup & copy php.ini
            ['label' => 'Backup & copy php.ini', 'fn' => function() use ($base) {
                $phpIni = '/etc/php/8.3/apache2/php.ini';
                if (file_exists($phpIni)) cmd("cp $phpIni {$phpIni}.backup");
                if (file_exists("$base/support/php.ini"))
                    cmd("cp $base/support/php.ini /etc/php/8.3/apache2/");
                return true;
            }],

            // 14. buat direktori-direktori
            ['label' => 'Membuat struktur direktori /home/*', 'fn' => function() {
                mkdirLocked('/home/root');
                mkdirLocked('/home/pma');
                mkdirLocked('/home/www');
                mkdirLocked('/home/datauser');
                mkdirLocked('/home/xcodehoster');
                mkdirLocked('/home/datapengguna');
                mkdirLocked('/home/domain');
                mkdirLocked('/home/checkdata');
                mkdirLocked('/home/checkdata2');
                // touch /home/datauser (file, bukan dir — sama persis bash)
                touch('/home/datauser');
                return true;
            }],

            // 15. chmod 777 /home/datauser
            ['label' => 'Set permission /home/datauser', 'fn' => function() {
                cmd('chmod 777 /home/datauser');
                return true;
            }],

            // 16. copy filemanager ke /home/filemanager
            ['label' => 'Install File Manager', 'fn' => function() use ($base) {
                if (is_dir("$base/filemanager"))
                    cmd("cp -r $base/filemanager /home/filemanager");
                cmd('chmod -R 777 /home');
                return true;
            }],

            // 17. a2enmod cgi, chmod cgi-bin
            ['label' => 'Aktifkan modul CGI & set permission', 'fn' => function() {
                cmd('a2enmod cgi');
                cmd('chmod 777 /usr/lib/cgi-bin');
                cmd('chmod 777 /home');
                cmd('chmod 777 /etc/apache2/sites-available');
                return true;
            }],

            // 18. tambah www-data ke sudoers
            ['label' => 'Konfigurasi sudoers (www-data)', 'fn' => function() {
                $line    = "www-data ALL=(ALL) NOPASSWD: ALL\n";
                $content = file_get_contents('/etc/sudoers');
                if (strpos($content, 'www-data ALL=(ALL) NOPASSWD: ALL') === false)
                    file_put_contents('/etc/sudoers', $line, FILE_APPEND);
                return true;
            }],

            // 19. buat /etc/apache2/ssl
            ['label' => 'Buat direktori SSL Apache', 'fn' => function() {
                if (!is_dir('/etc/apache2/ssl')) mkdir('/etc/apache2/ssl', 0777, true);
                cmd('chmod 777 /etc/apache2/ssl');
                return true;
            }],

            // 20. sed & konfigurasi file support (run.cgi, formdata.cgi, aktivasi3.cgi, index.html, filemanager)
            ['label' => 'Konfigurasi file support (CGI & HTML)', 'fn' => function() use ($base, $domain, $pwParam, $zoneid, $email, $apikey, $ip) {
                // run.cgi
                sedFile("$base/support/run.cgi", '-ppasswordmysql', $pwParam);
                sedFile("$base/support/run.cgi", 'xcodehoster.com', $domain);
                // formdata.cgi
                sedFile("$base/support/formdata.cgi", 'xcodehoster.com', $domain);
                // aktivasi3.cgi
                sedFile("$base/support/aktivasi3.cgi", 'xcodehoster.com', $domain);
                // subdomain.conf SSL
                sedFile("$base/support/subdomain.conf", 'xcodehoster.com.pem', "$domain.pem");
                sedFile("$base/support/subdomain.conf", 'xcodehoster.com.key', "$domain.key");
                // domain.conf SSL
                sedFile("$base/support/domain.conf", 'xcodehoster.com.pem', "$domain.pem");
                sedFile("$base/support/domain.conf", 'xcodehoster.com.key', "$domain.key");
                // index.html
                sedFile("$base/support/index.html", 'xcodehoster.com', $domain);
                // filemanager
                sedFile('/home/filemanager/index.html', 'xcodehoster.com', $domain);
                return true;
            }],

            // 21. copy CGI scripts ke /usr/lib/cgi-bin
            ['label' => 'Deploy CGI scripts ke /usr/lib/cgi-bin', 'fn' => function() use ($base, $domain, $pwParam, $zoneid, $email, $apikey, $ip) {
                $cgiFiles = [
                    "$base/support/formfree.cgi"  => '/usr/lib/cgi-bin/formfree.cgi',
                    "$base/support/run.cgi"        => '/usr/lib/cgi-bin/run.cgi',
                    "$base/support/aktivasi3.cgi"  => '/usr/lib/cgi-bin/aktivasi3.cgi',
                    "$base/support/formdata.cgi"   => '/usr/lib/cgi-bin/formdata.cgi',
                    "$base/support/acak.txt"       => '/usr/lib/cgi-bin/acak.txt',
                ];
                foreach ($cgiFiles as $src => $dst)
                    if (file_exists($src)) copy($src, $dst);
                cmd('chmod 777 /usr/lib/cgi-bin/acak.txt');
                touch('/usr/lib/cgi-bin/vouchers.txt');
                // update CGI yang sudah dicopy
                sedFile('/usr/lib/cgi-bin/run.cgi',       '-ppasswordmysql', $pwParam);
                sedFile('/usr/lib/cgi-bin/run.cgi',       'xcodehoster.com', $domain);
                sedFile('/usr/lib/cgi-bin/aktivasi3.cgi', 'domain',          $domain);
                sedFile('/usr/lib/cgi-bin/aktivasi3.cgi', 'zoneid',          $zoneid);
                sedFile('/usr/lib/cgi-bin/aktivasi3.cgi', 'email',           $email);
                sedFile('/usr/lib/cgi-bin/aktivasi3.cgi', 'globalapikey',    $apikey);
                sedFile('/usr/lib/cgi-bin/aktivasi3.cgi', 'ipserver',        $ip);
                // tulis ip.txt
                file_put_contents('/usr/lib/cgi-bin/ip.txt', $ip);
                return true;
            }],

            // 22. copy file support ke /home/xcodehoster & deploy ke /var/www/html
            ['label' => 'Deploy file web ke /home/xcodehoster & /var/www/html', 'fn' => function() use ($base, $domain) {
                $assets = ['domain.conf','domain2.conf','subdomain.conf','index.html',
                           'bootstrap.min.css','hosting.jpg','xcodehoster21x.png',
                           'coverxcodehoster.png'];
                foreach ($assets as $f)
                    if (file_exists("$base/support/$f")) copy("$base/support/$f", "/home/xcodehoster/$f");
                if (file_exists('/var/www/html/index.html'))
                    copy('/var/www/html/index.html', '/var/www/html/backup1.html');
                cmd('cp /home/xcodehoster/* /var/www/html/');
                return true;
            }],

            // 23. restart apache
            ['label' => 'Restart Apache', 'fn' => function() {
                cmd('service apache2 restart');
                return true;
            }],

            // 24. tulis sertifikat SSL
            ['label' => 'Tulis sertifikat SSL (.pem & .key)', 'fn' => function() use ($domain, $pem, $key) {
                file_put_contents("/etc/apache2/ssl/$domain.pem", $pem);
                file_put_contents("/etc/apache2/ssl/$domain.key", $key);
                return true;
            }],

            // 25. copy & konfigurasi virtual host domain.conf
            ['label' => 'Konfigurasi Virtual Host Apache', 'fn' => function() use ($base, $domain) {
                $src = "$base/support/domain.conf";
                $dst = "/etc/apache2/sites-available/$domain.conf";
                if (file_exists($src)) {
                    copy($src, $dst);
                    sedFile($dst, "sample.$domain", $domain);
                    sedFile($dst, 'sample',          'xcodehoster');
                    sedFile($dst, 'xcodehoster.com.pem', "$domain.pem");
                    sedFile($dst, 'xcodehoster.com.key', "$domain.key");
                    cmd("a2ensite $domain.conf");
                }
                return true;
            }],

            // 26. konfigurasi Cloudflare di aktivasi3.cgi
            ['label' => 'Konfigurasi Cloudflare (Zone ID, Email, API Key)', 'fn' => function() use ($base, $domain, $zoneid, $email, $apikey, $ip) {
                // support/aktivasi3.cgi
                sedFile("$base/support/aktivasi3.cgi", 'zoneid',       $zoneid);
                sedFile("$base/support/aktivasi3.cgi", 'email',        $email);
                sedFile("$base/support/aktivasi3.cgi", 'globalapikey', $apikey);
                sedFile("$base/support/aktivasi3.cgi", 'ipserver',     $ip);
                sedFile("$base/support/aktivasi3.cgi", 'domain',       $domain);
                // /usr/lib/cgi-bin/aktivasi3.cgi (sudah dicopy di step 21, update lagi)
                if (file_exists('/usr/lib/cgi-bin/aktivasi3.cgi')) {
                    sedFile('/usr/lib/cgi-bin/aktivasi3.cgi', 'zoneid',       $zoneid);
                    sedFile('/usr/lib/cgi-bin/aktivasi3.cgi', 'email',        $email);
                    sedFile('/usr/lib/cgi-bin/aktivasi3.cgi', 'globalapikey', $apikey);
                    sedFile('/usr/lib/cgi-bin/aktivasi3.cgi', 'ipserver',     $ip);
                }
                return true;
            }],

            // 27. generate 1000 voucher
            ['label' => 'Generate 1000 voucher', 'fn' => function() use ($domain) {
                $vouchers = generateVouchers(1000);
                file_put_contents('/usr/lib/cgi-bin/vouchers.txt', $vouchers);
                $rand = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
                $vFile = "vouchers{$rand}.txt";
                copy('/usr/lib/cgi-bin/vouchers.txt', "/home/xcodehoster/$vFile");
                copy('/usr/lib/cgi-bin/vouchers.txt', "/var/www/html/$vFile");
                $_SESSION['voucher_file'] = $vFile;
                return true;
            }],

            // 28. restart apache & finalisasi
            ['label' => 'Restart Apache & finalisasi instalasi', 'fn' => function() {
                cmd('service apache2 restart');
                touch(LOCK_FILE);
                return true;
            }],
        ];

        $total = count($steps);

        if ($step >= $total) {
            $domain  = $d['domain'];
            $voucher = "https://$domain/" . ($_SESSION['voucher_file'] ?? '');
            echo json_encode(['ok' => true, 'done' => true, 'domain' => $domain, 'voucher' => $voucher]);
            exit;
        }

        $cur = $steps[$step];
        try {
            $ok = ($cur['fn'])();
            $_SESSION['step'] = $step + 1;
            echo json_encode([
                'ok'      => true,
                'step'    => $step,
                'total'   => $total,
                'label'   => $cur['label'],
                'success' => $ok,
                'done'    => false,
            ]);
        } catch (Throwable $e) {
            logMsg("ERROR step $step: " . $e->getMessage());
            echo json_encode(['ok' => false, 'error' => $e->getMessage(), 'step' => $step]);
        }
        exit;
    }
}

$alreadyInstalled = file_exists(LOCK_FILE);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Xcodehoster v11 – Web Installer</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=Barlow:wght@400;600;800&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg:      #060a10;
  --panel:   #0d1420;
  --border:  #1a2535;
  --accent:  #00e5ff;
  --green:   #00e676;
  --red:     #ff1744;
  --yellow:  #ffd740;
  --text:    #cdd6e8;
  --muted:   #4a607a;
  --r:       10px;
}

body {
  background: var(--bg);
  color: var(--text);
  font-family: 'Barlow', sans-serif;
  min-height: 100vh;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: 3rem 1rem 4rem;
  background-image:
    radial-gradient(ellipse 60% 40% at 10% 0%, rgba(0,229,255,.07) 0%, transparent 70%),
    radial-gradient(ellipse 50% 30% at 90% 100%, rgba(0,230,118,.05) 0%, transparent 70%);
}

.wrap { width: 100%; max-width: 660px; }

/* ── Header ── */
.hdr { text-align: center; margin-bottom: 2.5rem; }
.hdr-badge {
  display: inline-block;
  background: linear-gradient(135deg, var(--accent), #0090b8);
  color: #000;
  font-family: 'IBM Plex Mono', monospace;
  font-size: .7rem;
  font-weight: 600;
  padding: .25rem .75rem;
  border-radius: 99px;
  letter-spacing: .1em;
  margin-bottom: .9rem;
}
.hdr h1 { font-size: 2.2rem; font-weight: 800; letter-spacing: -.03em; line-height: 1; }
.hdr h1 span { color: var(--accent); }
.hdr p { color: var(--muted); font-family: 'IBM Plex Mono', monospace; font-size: .78rem; margin-top: .5rem; }

/* ── Card ── */
.card {
  background: var(--panel);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 1.75rem;
  margin-bottom: 1.25rem;
  position: relative;
  overflow: hidden;
}
.card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2px;
  background: linear-gradient(90deg, var(--accent), transparent);
}
.card-title {
  font-family: 'IBM Plex Mono', monospace;
  font-size: .7rem;
  font-weight: 600;
  color: var(--accent);
  text-transform: uppercase;
  letter-spacing: .15em;
  margin-bottom: 1.25rem;
}

/* ── Form ── */
.grid  { display: grid; gap: .9rem; }
.row2  { display: grid; grid-template-columns: 1fr 1fr; gap: .9rem; }
.fg    { display: flex; flex-direction: column; gap: .35rem; }
.fg label {
  font-family: 'IBM Plex Mono', monospace;
  font-size: .68rem;
  color: var(--muted);
  text-transform: uppercase;
  letter-spacing: .1em;
}
.fg input, .fg textarea {
  background: rgba(255,255,255,.03);
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: .65rem .9rem;
  color: var(--text);
  font-family: 'IBM Plex Mono', monospace;
  font-size: .82rem;
  width: 100%;
  transition: border-color .2s, box-shadow .2s;
}
.fg textarea { resize: vertical; min-height: 110px; }
.fg input:focus, .fg textarea:focus {
  outline: none;
  border-color: var(--accent);
  box-shadow: 0 0 0 3px rgba(0,229,255,.08);
}
.fg .hint { font-size: .7rem; color: var(--muted); font-family: 'IBM Plex Mono', monospace; }

/* ── Button ── */
.btn {
  width: 100%;
  padding: .9rem;
  border: none;
  border-radius: 7px;
  font-family: 'Barlow', sans-serif;
  font-size: 1rem;
  font-weight: 800;
  cursor: pointer;
  letter-spacing: .04em;
  transition: opacity .2s, transform .15s;
  margin-top: .5rem;
}
.btn-primary {
  background: linear-gradient(135deg, var(--accent) 0%, #00b8cc 100%);
  color: #000;
}
.btn-primary:hover:not(:disabled) { opacity: .88; transform: translateY(-1px); }
.btn-primary:disabled { opacity: .3; cursor: not-allowed; }

/* ── Warning ── */
.warn {
  background: rgba(255,215,64,.07);
  border: 1px solid rgba(255,215,64,.25);
  border-radius: 7px;
  padding: .9rem 1.1rem;
  font-family: 'IBM Plex Mono', monospace;
  font-size: .78rem;
  color: var(--yellow);
  margin-bottom: 1.25rem;
}

/* ── Progress ── */
#progress-section { display: none; }
.pbar-wrap {
  background: rgba(255,255,255,.05);
  border-radius: 99px;
  height: 6px;
  overflow: hidden;
  margin-bottom: 1.5rem;
}
.pbar {
  height: 100%;
  background: linear-gradient(90deg, var(--accent), var(--green));
  border-radius: 99px;
  width: 0%;
  transition: width .5s ease;
}
.pct {
  font-family: 'IBM Plex Mono', monospace;
  font-size: .75rem;
  color: var(--muted);
  text-align: right;
  margin-top: .3rem;
  margin-bottom: 1rem;
}
.step-list {
  display: flex;
  flex-direction: column;
  gap: .4rem;
  max-height: 360px;
  overflow-y: auto;
  padding-right: 4px;
}
.step-item {
  display: flex;
  align-items: center;
  gap: .7rem;
  padding: .55rem .8rem;
  border-radius: 6px;
  font-family: 'IBM Plex Mono', monospace;
  font-size: .78rem;
  background: rgba(255,255,255,.025);
  transition: background .2s;
}
.step-item.running { background: rgba(0,229,255,.06); border: 1px solid rgba(0,229,255,.15); }
.step-item.ok      { opacity: .55; }
.step-item.fail    { background: rgba(255,23,68,.07); border: 1px solid rgba(255,23,68,.2); color: #ff6b6b; }
.si { flex-shrink: 0; font-size: .95rem; }
.spin {
  width: 14px; height: 14px;
  border: 2px solid rgba(0,229,255,.25);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin .65s linear infinite;
  flex-shrink: 0;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* ── Success ── */
#success-section { display: none; }
.success-inner { text-align: center; padding: 1.5rem 0 .5rem; }
.s-icon  { font-size: 3rem; margin-bottom: .75rem; }
.s-title { font-size: 1.75rem; font-weight: 800; color: var(--green); margin-bottom: .4rem; }
.s-sub   { color: var(--muted); font-size: .9rem; margin-bottom: 1.75rem; }
.link-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  background: rgba(255,255,255,.03);
  border: 1px solid var(--border);
  border-radius: 7px;
  padding: .7rem 1rem;
  margin-bottom: .6rem;
  text-align: left;
}
.lr-label { font-family: 'IBM Plex Mono', monospace; font-size: .65rem; color: var(--muted); text-transform: uppercase; letter-spacing: .1em; }
.lr-url   { font-family: 'IBM Plex Mono', monospace; font-size: .82rem; color: var(--accent); word-break: break-all; }
.lr-btn   { color: var(--accent); font-size: .78rem; text-decoration: none; white-space: nowrap; }

/* ── Step counter label ── */
.step-counter { font-family: 'IBM Plex Mono', monospace; font-size: .7rem; color: var(--muted); margin-bottom: .75rem; }

/* scrollbar */
.step-list::-webkit-scrollbar { width: 3px; }
.step-list::-webkit-scrollbar-track { background: transparent; }
.step-list::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }

@media (max-width:480px) {
  .row2 { grid-template-columns: 1fr; }
  .card { padding: 1.25rem; }
}
</style>
</head>
<body>
<div class="wrap">

  <!-- Header -->
  <div class="hdr">
    <div class="hdr-badge">WEB INSTALLER · V11</div>
    <h1>Xcode<span>Hoster</span></h1>
    <p>xcode.or.id &nbsp;·&nbsp; Ubuntu Server 24.04 LTS</p>
  </div>

  <?php if ($alreadyInstalled): ?>
  <div class="warn">⚠ Installer sudah pernah dijalankan. Hapus file <code>.installed</code> jika ingin install ulang.</div>
  <?php endif; ?>

  <!-- ── FORM ── -->
  <div id="form-section">

    <div class="card">
      <div class="card-title">// Informasi Server</div>
      <div class="grid">
        <div class="row2">
          <div class="fg">
            <label>IP Publik Server</label>
            <input type="text" id="ip" placeholder="103.xxx.xxx.xxx">
          </div>
          <div class="fg">
            <label>Nama Domain</label>
            <input type="text" id="domain" placeholder="hosting.domainanda.com">
          </div>
        </div>
        <div class="fg">
          <label>Password Root MySQL (baru)</label>
          <input type="password" id="password" placeholder="Buat password kuat">
          <span class="hint">Password ini akan di-set sebagai root MySQL</span>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">// Konfigurasi Cloudflare</div>
      <div class="grid">
        <div class="row2">
          <div class="fg">
            <label>Email Cloudflare</label>
            <input type="email" id="email" placeholder="email@domain.com">
          </div>
          <div class="fg">
            <label>Zone ID</label>
            <input type="text" id="zoneid" placeholder="Zone ID dari dashboard CF">
          </div>
        </div>
        <div class="fg">
          <label>Global API Key</label>
          <input type="password" id="apikey" placeholder="Global API Key Cloudflare">
          <span class="hint">Profil Cloudflare → API Tokens → Global API Key → View</span>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">// Sertifikat SSL</div>
      <div class="grid">
        <div class="fg">
          <label>Isi file .pem (Certificate)</label>
          <textarea id="pem" placeholder="-----BEGIN CERTIFICATE-----
...
-----END CERTIFICATE-----"></textarea>
        </div>
        <div class="fg">
          <label>Isi file .key (Private Key)</label>
          <textarea id="key" placeholder="-----BEGIN PRIVATE KEY-----
...
-----END PRIVATE KEY-----"></textarea>
        </div>
      </div>
    </div>

    <button class="btn btn-primary" id="btn-start" onclick="startInstall()" <?= $alreadyInstalled ? 'disabled' : '' ?>>
      ▶ &nbsp;MULAI INSTALASI
    </button>
  </div>

  <!-- ── PROGRESS ── -->
  <div id="progress-section">
    <div class="card">
      <div class="card-title">// Proses Instalasi</div>
      <div class="pbar-wrap"><div class="pbar" id="pbar"></div></div>
      <div class="pct" id="pct">0%</div>
      <div class="step-counter" id="step-counter">Langkah 0 / 28</div>
      <div class="step-list" id="step-list"></div>
    </div>
  </div>

  <!-- ── SUCCESS ── -->
  <div id="success-section">
    <div class="card">
      <div class="success-inner">
        <div class="s-icon">✅</div>
        <div class="s-title">Instalasi Selesai!</div>
        <div class="s-sub">Xcodehoster v11 berhasil diinstall di server Anda.</div>
        <div id="success-links"></div>
      </div>
    </div>
  </div>

</div><!-- /wrap -->

<script>
async function startInstall() {
  const f = {
    ip:       val('ip'),
    password: val('password'),
    domain:   val('domain'),
    zoneid:   val('zoneid'),
    email:    val('email'),
    apikey:   val('apikey'),
    pem:      val('pem'),
    key:      val('key'),
  };

  for (const [k, v] of Object.entries(f)) {
    if (!v) { alert(`Field "${k}" wajib diisi!`); return; }
  }

  document.getElementById('btn-start').disabled = true;

  // kirim data
  const fd = new FormData();
  fd.append('action', 'start');
  Object.entries(f).forEach(([k,v]) => fd.append(k, v));
  const res  = await fetch('', { method:'POST', body:fd });
  const data = await res.json();

  if (!data.ok) { alert('Error: ' + data.error); document.getElementById('btn-start').disabled = false; return; }

  document.getElementById('form-section').style.display    = 'none';
  document.getElementById('progress-section').style.display = 'block';

  runStep();
}

async function runStep() {
  const fd = new FormData();
  fd.append('action', 'step');
  const res  = await fetch('', { method:'POST', body:fd });
  const data = await res.json();

  if (!data.ok) {
    addStep('❌ Error: ' + data.error, 'fail');
    return;
  }

  if (data.done) {
    showSuccess(data.domain, data.voucher);
    return;
  }

  const pct = Math.round(((data.step + 1) / data.total) * 100);
  document.getElementById('pbar').style.width         = pct + '%';
  document.getElementById('pct').textContent          = pct + '%';
  document.getElementById('step-counter').textContent = `Langkah ${data.step + 1} / ${data.total}`;

  addStep(data.label, data.success ? 'ok' : 'fail', data.success ? '✔' : '✖');

  setTimeout(runStep, 200);
}

function addStep(label, status, icon = '⟳') {
  const list = document.getElementById('step-list');
  const el   = document.createElement('div');
  el.className = 'step-item ' + status;
  el.innerHTML = `<span class="si">${icon}</span>${label}`;
  list.appendChild(el);
  list.scrollTop = list.scrollHeight;
}

function showSuccess(domain, voucher) {
  document.getElementById('progress-section').style.display = 'none';
  document.getElementById('success-section').style.display  = 'block';

  document.getElementById('success-links').innerHTML = `
    <div class="link-row">
      <div><div class="lr-label">Website Hosting</div><div class="lr-url">https://${domain}</div></div>
      <a class="lr-btn" href="https://${domain}" target="_blank">Buka →</a>
    </div>
    <div class="link-row">
      <div><div class="lr-label">phpMyAdmin</div><div class="lr-url">https://${domain}/phpmyadmin</div></div>
      <a class="lr-btn" href="https://${domain}/phpmyadmin" target="_blank">Buka →</a>
    </div>
    <div class="link-row">
      <div><div class="lr-label">Daftar Voucher</div><div class="lr-url">${voucher}</div></div>
      <a class="lr-btn" href="${voucher}" target="_blank">Buka →</a>
    </div>
  `;
}

function val(id) { return document.getElementById(id).value.trim(); }
</script>
</body>
</html>
