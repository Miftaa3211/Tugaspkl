<?php
/**
 * Xcodehoster v11 - Web Installer (PHP)
 * Programmer : Kurniawan. kurniawanajazenfone@gmail.com. xcode.or.id.
 * X-code Media - xcode.or.id / xcode.co.id
 *
 * Cara pakai: Letakkan di dalam folder xcodehosterv11, akses via browser.
 * Contoh: http://IP-SERVER/xcodehosterv11/install_web.php
 */

session_start();

function jalankan(string $cmd): string {
    $output = [];
    exec($cmd . ' 2>&1', $output);
    return implode("\n", $output);
}

// ── Handle POST: simpan data ke session ───────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    if ($_POST['action'] === 'install') {
        $ipserver      = trim($_POST['ipserver'] ?? '');
        $passwordmysql = trim($_POST['passwordmysql'] ?? '');
        $domain        = trim($_POST['domain'] ?? '');
        $zoneid        = trim($_POST['zoneid'] ?? '');
        $email         = trim($_POST['email'] ?? '');
        $globalapikey  = trim($_POST['globalapikey'] ?? '');
        $sslpem        = trim($_POST['sslpem'] ?? '');
        $sslkey        = trim($_POST['sslkey'] ?? '');

        if (!$ipserver || !$passwordmysql || !$domain || !$zoneid || !$email || !$globalapikey) {
            echo json_encode(['success' => false, 'message' => 'Semua field wajib diisi.']);
            exit;
        }
        if (!preg_match('/^[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/', $domain)) {
            echo json_encode(['success' => false, 'message' => 'Format domain tidak valid.']);
            exit;
        }

        $_SESSION['install_data'] = compact('ipserver','passwordmysql','domain','zoneid','email','globalapikey','sslpem','sslkey');
        echo json_encode(['success' => true]);
        exit;
    }

    exit;
}

// ── Streaming install (SSE) ───────────────────────────────────────────────────
if (isset($_GET['stream'])) {
    if (empty($_SESSION['install_data'])) {
        echo "data: " . json_encode(['log' => '❌ Data tidak ditemukan.', 'done' => true]) . "\n\n";
        exit;
    }

    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('X-Accel-Buffering: no');
    ob_implicit_flush(true);
    if (ob_get_level()) ob_end_flush();

    extract($_SESSION['install_data']);
    $installDir = __DIR__;
    $supportDir = $installDir . '/support';
    $fmDir      = $installDir . '/filemanager';

    function kirim(string $log, bool $done = false, int $pct = 0, array $result = []): void {
        $payload = ['log' => $log, 'done' => $done, 'pct' => $pct];
        if (!empty($result)) $payload['result'] = $result;
        echo "data: " . json_encode($payload) . "\n\n";
        flush();
    }

    // Cek Ubuntu 24.04
    $osVer = trim(shell_exec("lsb_release -r | awk '{print \$2}'"));
    if ($osVer !== '24.04') {
        kirim("❌ Aplikasi ini tidak mendukung distro Linux Anda. Install pada Ubuntu versi 24.04", true, 0);
        exit;
    }
    kirim("Xcodehoster v11 - 6 Oktober 2025", false, 2);
    kirim("Versi Ubuntu anda didukung oleh aplikasi ini, Ubuntu $osVer", false, 4);

    kirim("Menjalankan apt-get update...", false, 5);
    jalankan("apt-get update");
    jalankan("apt -y install software-properties-common");
    kirim("Install Apache2...", false, 8);
    jalankan("apt install -y apache2");
    kirim("Install PHP...", false, 12);
    jalankan("apt install -y php");
    jalankan("cp $supportDir/phpinfo.php /var/www/html 2>/dev/null");
    kirim("Install MySQL Server...", false, 16);
    jalankan("apt install -y mysql-server");

    kirim("Mengatur password root MySQL...", false, 20);
    jalankan("mysql -e \"ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '$passwordmysql';\"");

    kirim("Install phpMyAdmin...", false, 24);
    jalankan("DEBIAN_FRONTEND=noninteractive apt install -y phpmyadmin");

    kirim("Install zip, unzip, php-zip...", false, 28);
    jalankan("apt-get install -y zip unzip php-zip");

    kirim("Aktifkan modul Apache (ssl, cgi)...", false, 32);
    jalankan("a2enmod ssl");
    jalankan("service apache2 restart");

    kirim("Backup & copy apache2.conf...", false, 36);
    jalankan("cp /etc/apache2/apache2.conf " . $installDir . "/backup");
    jalankan("cp $supportDir/apache2.conf /etc/apache2/");

    kirim("Konfigurasi domain: $domain", false, 40);
    jalankan("sed -i \"s/xcodehoster.com/$domain/g\" $supportDir/subdomain.conf");
    jalankan("sed -i \"s/sample.xcodehoster.com/$domain/g\" $supportDir/domain.conf");

    kirim("Copy php.ini...", false, 43);
    jalankan("cp /etc/php/8.3/apache2/php.ini /etc/php/8.3/apache2/phpini.backup");
    jalankan("cp $supportDir/php.ini /etc/php/8.3/apache2");

    kirim("Membuat direktori sistem...", false, 46);
    $dirs = ['/home/root','/home/pma','/home/www','/home/datauser',
             '/home/xcodehoster','/home/datapengguna','/home/domain',
             '/home/checkdata','/home/checkdata2','/home/filemanager',
             '/home/server','/home/recovery'];
    foreach ($dirs as $d) {
        if (!is_dir($d)) mkdir($d, 0777, true);
    }
    $locks = ['/home/root/locked','/home/pma/locked','/home/www/locked',
              '/home/datauser/locked','/home/datapengguna/locked',
              '/home/domain/locked','/home/checkdata/locked','/home/checkdata2/locked'];
    foreach ($locks as $lf) { if (!file_exists($lf)) touch($lf); }

    kirim("Copy filemanager...", false, 50);
    jalankan("chmod 777 /home/datauser");
    jalankan("cp -r $fmDir/. /home/filemanager/");
    jalankan("chmod -R 777 /home");
    jalankan("a2enmod cgi");
    jalankan("chmod 777 /usr/lib/cgi-bin");
    jalankan("chmod 777 /etc/apache2/sites-available");
    jalankan("sed -i \"/more/i\\www-data ALL=(ALL) NOPASSWD: ALL\" /etc/sudoers");
    jalankan("mkdir -p /etc/apache2/ssl && chmod 777 /etc/apache2/ssl");
    jalankan("apt install -y jq imagemagick");

    kirim("Update file konfigurasi dengan domain & password...", false, 55);
    $passwordFlag = "-p$passwordmysql";
    jalankan("sed -i \"s/-ppasswordmysql/$passwordFlag/g\" $supportDir/run.cgi");
    jalankan("sed -i \"s/xcodehoster.com/$domain/g\" $supportDir/formdata.cgi");
    jalankan("sed -i \"s/xcodehoster.com/$domain/g\" $supportDir/run.cgi");
    jalankan("sed -i \"s/xcodehoster.com/$domain/g\" $supportDir/aktivasi3.cgi");
    jalankan("sed -i \"s/xcodehoster.com/$domain/g\" /home/filemanager/index.html");
    jalankan("sed -i \"s/xcodehoster.com.pem/$domain.pem/g\" $supportDir/subdomain.conf");
    jalankan("sed -i \"s/xcodehoster.com.key/$domain.key/g\" $supportDir/subdomain.conf");
    jalankan("sed -i \"s/xcodehoster.com.pem/$domain.pem/g\" $supportDir/domain.conf");
    jalankan("sed -i \"s/xcodehoster.com/$domain/g\" $supportDir/index.html");

    kirim("Copy CGI files...", false, 60);
    foreach (['formfree.cgi','run.cgi','aktivasi3.cgi','formdata.cgi','acak.txt'] as $f) {
        if (file_exists("$supportDir/$f")) jalankan("cp $supportDir/$f /usr/lib/cgi-bin/");
    }
    if (!file_exists('/usr/lib/cgi-bin/vouchers.txt')) touch('/usr/lib/cgi-bin/vouchers.txt');
    jalankan("chmod 777 /usr/lib/cgi-bin/acak.txt");

    kirim("Copy files ke /home/xcodehoster...", false, 64);
    foreach (['domain.conf','domain2.conf','subdomain.conf','index.html',
              'bootstrap.min.css','hosting.jpg','xcodehoster21x.png','coverxcodehoster.png'] as $f) {
        if (file_exists("$supportDir/$f")) jalankan("cp $supportDir/$f /home/xcodehoster/");
    }
    jalankan("mkdir -p /etc/apache2/ssl");
    jalankan("cp /var/www/html/index.html /var/www/html/backup1.html 2>/dev/null");
    jalankan("cp /home/xcodehoster/* /var/www/html/");
    jalankan("service apache2 restart");

    kirim("Membuat VirtualHost config...", false, 68);
    jalankan("cp $supportDir/domain.conf /etc/apache2/sites-available/$domain.conf");
    jalankan("sed -i \"s/sample.$domain/$domain/g\" /etc/apache2/sites-available/$domain.conf");
    jalankan("sed -i \"s/sample/xcodehoster/g\" /etc/apache2/sites-available/$domain.conf");
    jalankan("sed -i \"s/xcodehoster.com.pem/$domain.pem/g\" /etc/apache2/sites-available/$domain.conf");
    jalankan("sed -i \"s/xcodehoster.com.key/$domain.key/g\" /etc/apache2/sites-available/$domain.conf");

    kirim("Menyimpan SSL Certificate...", false, 72);
    $pemFile = "/etc/apache2/ssl/$domain.pem";
    $keyFile = "/etc/apache2/ssl/$domain.key";
    if (!empty($sslpem) && !empty($sslkey)) {
        file_put_contents($pemFile, $sslpem);
        file_put_contents($keyFile, $sslkey);
        chmod($pemFile, 0644);
        chmod($keyFile, 0644);
        kirim("SSL Certificate dari Cloudflare disimpan", false, 76);
    } else {
        touch($pemFile);
        touch($keyFile);
        kirim("File SSL dibuat (kosong - isi manual setelah instalasi)", false, 76);
    }

    jalankan("a2ensite $domain.conf");

    kirim("Generate 1000 kode voucher...", false, 80);
    jalankan("for i in \$(seq 1 1000); do < /dev/urandom tr -dc 'A-Za-z0-9' | head -c 8; echo; done > /usr/lib/cgi-bin/vouchers.txt");

    kirim("Update konfigurasi Cloudflare...", false, 84);
    jalankan("sed -i \"s/domain/$domain/g\" /usr/lib/cgi-bin/aktivasi3.cgi");
    jalankan("sed -i \"s/zoneid/$zoneid/g\" $supportDir/aktivasi3.cgi");
    jalankan("sed -i \"s/zoneid/$zoneid/g\" /usr/lib/cgi-bin/aktivasi3.cgi");
    jalankan("sed -i \"s/email/$email/g\" $supportDir/aktivasi3.cgi");
    jalankan("sed -i \"s/email/$email/g\" /usr/lib/cgi-bin/aktivasi3.cgi");
    jalankan("sed -i \"s/globalapikey/$globalapikey/g\" $supportDir/aktivasi3.cgi");
    jalankan("sed -i \"s/globalapikey/$globalapikey/g\" /usr/lib/cgi-bin/aktivasi3.cgi");
    file_put_contents('/usr/lib/cgi-bin/ip.txt', $ipserver . "\n");
    jalankan("sed -i \"s/ipserver/$ipserver/g\" $supportDir/aktivasi3.cgi");
    jalankan("sed -i \"s/ipserver/$ipserver/g\" /usr/lib/cgi-bin/aktivasi3.cgi");

    kirim("Generate ulang voucher & simpan...", false, 88);
    jalankan("for i in \$(seq 1 1000); do < /dev/urandom tr -dc 'A-Za-z0-9' | head -c 8; echo; done > /usr/lib/cgi-bin/vouchers.txt");
    $random_number = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
    jalankan("cp /usr/lib/cgi-bin/vouchers.txt /home/xcodehoster/vouchers{$random_number}.txt");

    kirim("Restart Apache...", false, 94);
    jalankan("service apache2 restart");

    kirim("Instalasi selesai, untuk pengujian silahkan web hosting diakses di alamat $domain", false, 98);

    $result = [
        'website' => "https://$domain",
        'voucher' => "https://$domain/vouchers{$random_number}.txt",
        'domain'  => $domain,
        'ip'      => $ipserver,
    ];
    kirim("Instalasi selesai. Xcode.or.id", true, 100, $result);
    unset($_SESSION['install_data']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Xcodehoster v11 — Installer</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: Georgia, 'Times New Roman', serif;
    background: #f0ede8;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px 20px;
}

.wrap {
    width: 100%;
    max-width: 620px;
}

.logo-area {
    text-align: center;
    margin-bottom: 30px;
}
.logo-area h1 {
    font-size: 28px;
    font-weight: normal;
    color: #1a1a1a;
    letter-spacing: -0.5px;
}
.logo-area h1 span {
    color: #2563eb;
    font-style: italic;
}
.logo-area p {
    font-size: 13px;
    color: #888;
    margin-top: 4px;
    font-family: monospace;
}

.card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    overflow: hidden;
    box-shadow: 0 1px 4px rgba(0,0,0,0.08);
}

/* Step tabs */
.tabs {
    display: flex;
    border-bottom: 1px solid #ddd;
    background: #fafafa;
}
.tab {
    flex: 1;
    text-align: center;
    padding: 14px;
    font-size: 12px;
    color: #aaa;
    letter-spacing: 0.5px;
    text-transform: uppercase;
    font-family: monospace;
    border-bottom: 2px solid transparent;
}
.tab.active { color: #2563eb; border-bottom-color: #2563eb; background: #fff; }
.tab.done { color: #16a34a; }

/* Panels */
.panel { display: none; padding: 32px; }
.panel.active { display: block; }

.panel-title {
    font-size: 18px;
    color: #1a1a1a;
    margin-bottom: 6px;
    font-weight: normal;
}
.panel-desc {
    font-size: 13px;
    color: #888;
    margin-bottom: 24px;
    line-height: 1.6;
    font-family: Arial, sans-serif;
}

/* Form fields */
.field { margin-bottom: 18px; }
.field label {
    display: block;
    font-size: 12px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #444;
    margin-bottom: 6px;
    font-family: Arial, sans-serif;
}
.field input, .field textarea {
    width: 100%;
    border: 1px solid #ccc;
    border-radius: 3px;
    padding: 9px 12px;
    font-size: 14px;
    color: #1a1a1a;
    font-family: monospace;
    outline: none;
    transition: border-color .15s;
    background: #fefefe;
}
.field input:focus, .field textarea:focus {
    border-color: #2563eb;
    background: #fff;
}
.field .hint {
    font-size: 11px;
    color: #aaa;
    margin-top: 4px;
    font-family: Arial, sans-serif;
}

.section-label {
    font-size: 10px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: #aaa;
    border-top: 1px solid #eee;
    padding-top: 18px;
    margin: 18px 0 14px;
    font-family: Arial, sans-serif;
}

/* Buttons */
.btn-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 24px;
    padding-top: 20px;
    border-top: 1px solid #eee;
}
.btn {
    padding: 10px 24px;
    font-size: 14px;
    border-radius: 3px;
    cursor: pointer;
    border: none;
    font-family: Arial, sans-serif;
    transition: background .15s;
}
.btn-primary { background: #2563eb; color: #fff; }
.btn-primary:hover { background: #1d4ed8; }
.btn-primary:disabled { background: #93c5fd; cursor: not-allowed; }
.btn-ghost { background: none; color: #888; border: 1px solid #ddd; }
.btn-ghost:hover { background: #f5f5f5; }

/* Alert */
.alert {
    padding: 10px 14px;
    border-radius: 3px;
    font-size: 13px;
    margin-bottom: 16px;
    font-family: Arial, sans-serif;
}
.alert-error { background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; }

/* Progress panel */
.progress-wrap {
    background: #eee;
    border-radius: 2px;
    height: 4px;
    margin-bottom: 20px;
    overflow: hidden;
}
.progress-bar {
    height: 100%;
    background: #2563eb;
    width: 0%;
    transition: width .3s;
}
.pct-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
    font-family: Arial, sans-serif;
    font-size: 13px;
    color: #555;
}
.pct-num { font-family: monospace; color: #2563eb; font-size: 13px; }

.log-box {
    background: #1a1a1a;
    border-radius: 3px;
    padding: 16px;
    height: 280px;
    overflow-y: auto;
    font-family: monospace;
    font-size: 12px;
    line-height: 1.9;
    color: #aaa;
}
.log-ok  { color: #4ade80; }
.log-err { color: #f87171; }
.log-warn { color: #fbbf24; }

/* Result */
.result {
    margin-top: 20px;
    border: 1px solid #bbf7d0;
    background: #f0fdf4;
    border-radius: 3px;
    padding: 20px;
    font-family: Arial, sans-serif;
}
.result h3 { color: #15803d; font-size: 15px; margin-bottom: 14px; }
.result-row {
    display: flex;
    gap: 12px;
    padding: 7px 0;
    border-bottom: 1px solid #dcfce7;
    font-size: 13px;
}
.result-row:last-child { border-bottom: none; }
.result-row .lbl { color: #888; width: 120px; flex-shrink: 0; }
.result-row a { color: #2563eb; word-break: break-all; }
.result-row span { color: #1a1a1a; font-family: monospace; }

.note {
    font-size: 12px;
    color: #888;
    font-family: Arial, sans-serif;
    margin-top: 14px;
    line-height: 1.6;
}
.note strong { color: #555; }
</style>
</head>
<body>
<div class="wrap">

  <div class="logo-area">
    <h1>Xcode<span>hoster</span> v11</h1>
    <p>Web Installer · xcode.or.id</p>
  </div>

  <div class="card">
    <div class="tabs">
      <div class="tab active" id="tab1">① Server</div>
      <div class="tab" id="tab2">② Cloudflare</div>
      <div class="tab" id="tab3">③ SSL</div>
      <div class="tab" id="tab4">④ Proses</div>
    </div>

    <!-- PANEL 1: INFO SERVER -->
    <div class="panel active" id="panel1">
      <div class="panel-title">Informasi Server</div>
      <div class="panel-desc">Masukkan IP publik server, password MySQL yang akan dibuat, dan nama domain utama Anda.</div>

      <div id="alert1" style="display:none;"></div>

      <div class="field">
        <label>IP Publik Server</label>
        <input type="text" id="f-ip" placeholder="contoh: 202.10.42.16">
      </div>
      <div class="field">
        <label>Password MySQL Root</label>
        <input type="password" id="f-pass" placeholder="">
        <div class="hint">Password untuk user root MySQL yang akan dibuat.</div>
      </div>
      <div class="field">
        <label>Nama Domain</label>
        <input type="text" id="f-domain" placeholder="contoh: tugaspkl.my.id">
        <div class="hint">Tanpa http:// dan tanpa www</div>
      </div>

      <div class="btn-row">
        <span></span>
        <button class="btn btn-primary" onclick="next(1)">Lanjut →</button>
      </div>
    </div>

    <!-- PANEL 2: CLOUDFLARE -->
    <div class="panel" id="panel2">
      <div class="panel-title">Konfigurasi Cloudflare</div>
      <div class="panel-desc">Data Cloudflare digunakan untuk mengatur DNS subdomain secara otomatis setelah pendaftaran VPS.</div>

      <div id="alert2" style="display:none;"></div>

      <div class="field">
        <label>Zone ID</label>
        <input type="text" id="f-zoneid" placeholder="">
        <div class="hint">Tersedia di halaman Overview domain di Cloudflare.</div>
      </div>
      <div class="field">
        <label>Email Cloudflare</label>
        <input type="email" id="f-email" placeholder="">
      </div>
      <div class="field">
        <label>Global API Key</label>
        <input type="password" id="f-apikey" placeholder="">
        <div class="hint">My Profile → API Tokens → Global API Key → View</div>
      </div>

      <div class="btn-row">
        <button class="btn btn-ghost" onclick="goPanel(1)">← Kembali</button>
        <button class="btn btn-primary" onclick="next(2)">Lanjut →</button>
      </div>
    </div>

    <!-- PANEL 3: SSL -->
    <div class="panel" id="panel3">
      <div class="panel-title">SSL Certificate</div>
      <div class="panel-desc">Paste Cloudflare Origin Certificate untuk mengaktifkan HTTPS. Kosongkan jika ingin mengisi manual setelah instalasi.</div>

      <div class="field">
        <label>Certificate (.pem)</label>
        <textarea id="f-pem" rows="5" placeholder="-----BEGIN CERTIFICATE-----
(paste Cloudflare Origin Certificate di sini)
-----END CERTIFICATE-----"></textarea>
        <div class="hint">Opsional. Kosongkan jika akan diisi manual setelah instalasi.</div>
      </div>
      <div class="field">
        <label>Private Key (.key)</label>
        <textarea id="f-key" rows="5" placeholder="-----BEGIN PRIVATE KEY-----
(paste Private Key di sini)
-----END PRIVATE KEY-----"></textarea>
        <div class="hint">Opsional. Kosongkan jika akan diisi manual setelah instalasi.</div>
      </div>

      <div class="btn-row">
        <button class="btn btn-ghost" onclick="goPanel(2)">← Kembali</button>
        <button class="btn btn-primary" onclick="startInstall()">🚀 Mulai Instalasi</button>
      </div>
    </div>

    <!-- PANEL 4: PROSES -->
    <div class="panel" id="panel4">
      <div class="pct-row">
        <span id="pct-label">Mempersiapkan...</span>
        <span class="pct-num" id="pct-num">0%</span>
      </div>
      <div class="progress-wrap">
        <div class="progress-bar" id="prog"></div>
      </div>
      <div class="log-box" id="log-box"></div>
      <div id="result-box"></div>
      <div id="btn-done" style="display:none; text-align:right; margin-top:16px;">
        <button class="btn btn-ghost" onclick="location.reload()">Instalasi Baru</button>
      </div>
    </div>
  </div>

</div>

<script>
let cur = 1;

function goPanel(n) {
  document.getElementById('panel' + cur).classList.remove('active');
  document.getElementById('tab' + cur).classList.remove('active');
  if (n > cur) document.getElementById('tab' + cur).classList.add('done');
  cur = n;
  document.getElementById('panel' + n).classList.add('active');
  document.getElementById('tab' + n).classList.add('active');
}

function showAlert(panelNum, msg) {
  const el = document.getElementById('alert' + panelNum);
  el.style.display = 'block';
  el.innerHTML = '<div class="alert alert-error">' + msg + '</div>';
}
function hideAlert(panelNum) {
  document.getElementById('alert' + panelNum).style.display = 'none';
}

function next(from) {
  hideAlert(from);
  if (from === 1) {
    const ip = document.getElementById('f-ip').value.trim();
    const pass = document.getElementById('f-pass').value.trim();
    const domain = document.getElementById('f-domain').value.trim();
    if (!ip || !pass || !domain) return showAlert(1, 'Semua field wajib diisi.');
    goPanel(2);
  } else if (from === 2) {
    const z = document.getElementById('f-zoneid').value.trim();
    const e = document.getElementById('f-email').value.trim();
    const k = document.getElementById('f-apikey').value.trim();
    if (!z || !e || !k) return showAlert(2, 'Semua field wajib diisi.');
    goPanel(3);
  }
}

async function startInstall() {
  const fd = new FormData();
  fd.append('action',        'install');
  fd.append('ipserver',      document.getElementById('f-ip').value.trim());
  fd.append('passwordmysql', document.getElementById('f-pass').value.trim());
  fd.append('domain',        document.getElementById('f-domain').value.trim());
  fd.append('zoneid',        document.getElementById('f-zoneid').value.trim());
  fd.append('email',         document.getElementById('f-email').value.trim());
  fd.append('globalapikey',  document.getElementById('f-apikey').value.trim());
  fd.append('sslpem',        document.getElementById('f-pem').value.trim());
  fd.append('sslkey',        document.getElementById('f-key').value.trim());

  const res = await fetch('', {method:'POST', body: fd});
  const d = await res.json();
  if (!d.success) return alert(d.message);

  goPanel(4);
  stream();
}

function stream() {
  const log  = document.getElementById('log-box');
  const bar  = document.getElementById('prog');
  const pnum = document.getElementById('pct-num');
  const plbl = document.getElementById('pct-label');

  const src = new EventSource('?stream=1');
  src.onmessage = function(e) {
    const d = JSON.parse(e.data);

    const line = document.createElement('div');
    line.className = d.log.startsWith('✅') || d.log.startsWith('🎉') ? 'log-ok'
                   : d.log.startsWith('❌') ? 'log-err'
                   : d.log.startsWith('⚠') ? 'log-warn' : '';
    line.textContent = d.log;
    log.appendChild(line);
    log.scrollTop = log.scrollHeight;

    if (d.pct) {
      bar.style.width = d.pct + '%';
      pnum.textContent = d.pct + '%';
      plbl.textContent = d.log;
    }

    if (d.done) {
      src.close();
      plbl.textContent = 'Instalasi selesai!';
      document.getElementById('btn-done').style.display = 'block';
      if (d.result) showResult(d.result);
    }
  };
  src.onerror = function() {
    src.close();
    const line = document.createElement('div');
    line.className = 'log-err';
    line.textContent = '❌ Koneksi terputus.';
    log.appendChild(line);
  };
}

function showResult(r) {
  document.getElementById('result-box').innerHTML = `
    <div class="result">
      <h3>✅ Instalasi Berhasil!</h3>
      <div class="result-row"><span class="lbl">Website</span><a href="${r.website}" target="_blank">${r.website}</a></div>
      <div class="result-row"><span class="lbl">Voucher</span><a href="${r.voucher}" target="_blank">${r.voucher}</a></div>
      <div class="result-row"><span class="lbl">IP Server</span><span>${r.ip}</span></div>
      <p class="note">
        <strong>Langkah berikutnya:</strong><br>
        Arahkan DNS domain ke IP ${r.ip} via Cloudflare (SSL Flexible).<br>
        Jika SSL kosong, isi manual file <code>/etc/apache2/ssl/${r.domain}.pem</code> dan <code>.key</code> lalu restart Apache.
      </p>
    </div>`;
}
</script>
</body>
</html>
