<?php
/**
 * Xcodehoster v11 - Web Installer (PHP)
 * Programmer : Kurniawan. kurniawanajazenfone@gmail.com. xcode.or.id.
 * X-code Media - xcode.or.id / xcode.co.id
 *
 * Cara pakai: Letakkan di dalam folder xcodehosterv11, akses via browser.
 * Contoh: http://IP-SERVER/xcodehosterv11/install_web.php
 */

session_start();

// ── Helper: jalankan perintah shell ──────────────────────────────────────────
function jalankan(string $cmd): string {
    $output = [];
    exec($cmd . ' 2>&1', $output);
    return implode("\n", $output);
}

// ── Tangani AJAX install request ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    header('Content-Type: application/json');

    if ($_POST['action'] === 'install') {
        // Ambil input
        $ipserver      = trim($_POST['ipserver'] ?? '');
        $passwordmysql = trim($_POST['passwordmysql'] ?? '');
        $domain        = trim($_POST['domain'] ?? '');
        $zoneid        = trim($_POST['zoneid'] ?? '');
        $email         = trim($_POST['email'] ?? '');
        $globalapikey  = trim($_POST['globalapikey'] ?? '');
        $sslpem        = trim($_POST['sslpem'] ?? '');
        $sslkey        = trim($_POST['sslkey'] ?? '');

        // Validasi
        if (!$ipserver || !$passwordmysql || !$domain || !$zoneid || !$email || !$globalapikey) {
            echo json_encode(['success' => false, 'message' => 'Semua field wajib diisi.']);
            exit;
        }
        if (!preg_match('/^[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/', $domain)) {
            echo json_encode(['success' => false, 'message' => 'Format domain tidak valid.']);
            exit;
        }

        // Simpan ke session untuk streaming
        $_SESSION['install_data'] = compact('ipserver','passwordmysql','domain','zoneid','email','globalapikey','sslpem','sslkey');
        echo json_encode(['success' => true]);
        exit;
    }

    if ($_POST['action'] === 'check') {
        $os = trim(shell_exec("lsb_release -r | awk '{print $2}'"));
        $isRoot = true; // Web installer dijalankan oleh Apache, cek root tidak diperlukan
        $supportExists = is_dir(__DIR__ . '/support');
        echo json_encode([
            'os'      => $os,
            'isRoot'  => $isRoot,
            'support' => $supportExists,
            'ok'      => ($os === '24.04' && $isRoot && $supportExists),
        ]);
        exit;
    }

    exit;
}

// ── Streaming install ─────────────────────────────────────────────────────────
if (isset($_GET['stream'])) {
    if (empty($_SESSION['install_data'])) {
        echo "data: " . json_encode(['log' => '❌ Data tidak ditemukan. Ulangi dari awal.', 'done' => true]) . "\n\n";
        exit;
    }

    header('Content-Type: text/event-stream');
    header('Cache-Control: no-cache');
    header('X-Accel-Buffering: no');

    ob_implicit_flush(true);
    ob_end_flush();

    extract($_SESSION['install_data']);

    $installDir = __DIR__;
    $supportDir = $installDir . '/support';
    $fmDir      = $installDir . '/filemanager';

    function kirim(string $log, bool $done = false, int $pct = 0, array $result = []): void {
        $payload = ['log' => $log, 'done' => $done, 'pct' => $pct];
        if (!empty($result)) $payload['result'] = $result;
        $data = json_encode($payload);
        echo "data: $data\n\n";
        flush();
    }

    // ── STEP 1: Cek sistem ────────────────────────────────────────────────────
    kirim('🔍 Mengecek sistem...', false, 2);
    $osVer = trim(shell_exec("lsb_release -r | awk '{print \$2}'"));
    if ($osVer !== '24.04') {
        kirim("❌ Ubuntu $osVer tidak didukung. Harus Ubuntu 24.04.", true, 0); exit;
    }
    kirim("✅ Ubuntu $osVer didukung", false, 5);

    // ── STEP 2: Update & install paket ───────────────────────────────────────
    kirim('📦 Menjalankan apt-get update...', false, 8);
    jalankan('apt-get update -y');
    kirim('✅ apt update selesai', false, 10);

    kirim('📦 Install software-properties-common...', false, 12);
    jalankan('apt -y install software-properties-common');

    kirim('📦 Install Apache2...', false, 14);
    jalankan('apt install -y apache2');
    kirim('✅ Apache2 terinstall', false, 17);

    kirim('📦 Install PHP...', false, 18);
    jalankan('apt install -y php libapache2-mod-php php-mysql php-curl php-gd php-mbstring php-xml php-xmlrpc php-soap php-intl php-zip');
    kirim('✅ PHP terinstall', false, 22);

    kirim('📦 Install MySQL Server...', false, 23);
    jalankan('apt install -y mysql-server');
    kirim('✅ MySQL Server terinstall', false, 27);

    // ── STEP 3: Set password MySQL ────────────────────────────────────────────
    kirim('🔐 Mengatur password root MySQL...', false, 28);
    jalankan("mysql -e \"ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '$passwordmysql';\"");
    jalankan("mysql -uroot -p$passwordmysql -e \"FLUSH PRIVILEGES;\"");
    kirim('✅ Password MySQL diset', false, 30);

    // ── STEP 4: Install phpMyAdmin ────────────────────────────────────────────
    kirim('📦 Install phpMyAdmin (harap tunggu)...', false, 31);
    jalankan('DEBIAN_FRONTEND=noninteractive apt install -y phpmyadmin');
    kirim('✅ phpMyAdmin terinstall', false, 35);

    // Fix phpMyAdmin Apache conf
    if (!file_exists('/etc/apache2/conf-available/phpmyadmin.conf')) {
        if (file_exists('/etc/phpmyadmin/apache.conf')) {
            jalankan('ln -s /etc/phpmyadmin/apache.conf /etc/apache2/conf-available/phpmyadmin.conf');
        }
    }
    jalankan('a2enconf phpmyadmin 2>/dev/null');
    kirim('✅ phpMyAdmin aktif di Apache', false, 37);

    // ── STEP 5: Paket tambahan ────────────────────────────────────────────────
    kirim('📦 Install zip, jq, imagemagick...', false, 38);
    jalankan('apt-get install -y zip unzip php-zip');
    jalankan('apt install -y jq imagemagick');
    kirim('✅ Paket tambahan terinstall', false, 42);

    // ── STEP 6: Apache modules ────────────────────────────────────────────────
    kirim('⚙️  Aktifkan Apache modules (ssl, cgi, rewrite, headers)...', false, 43);
    jalankan('a2enmod ssl cgi rewrite headers');
    jalankan('service apache2 restart');
    kirim('✅ Apache modules aktif', false, 46);

    // ── STEP 7: Patch apache2.conf ────────────────────────────────────────────
    kirim('⚙️  Patch apache2.conf...', false, 47);
    $apacheConf = '/etc/apache2/apache2.conf';
    if (file_exists($apacheConf)) {
        copy($apacheConf, $apacheConf . '.bak');
        $isi = file_get_contents($apacheConf);
        $blok = "\n<Directory /home>\n    Options Indexes FollowSymLinks\n    AllowOverride All\n    Require all granted\n</Directory>\n";
        if (strpos($isi, '<Directory /home>') === false) {
            file_put_contents($apacheConf, $isi . $blok);
        }
    }
    jalankan('chmod o+x /home');
    kirim('✅ apache2.conf diupdate', false, 50);

    // ── STEP 8: Patch php.ini ─────────────────────────────────────────────────
    kirim('⚙️  Patch php.ini...', false, 51);
    $phpini = trim(shell_exec('php --ini | grep "Loaded Configuration" | awk \'{print $4}\''));
    if ($phpini && file_exists($phpini)) {
        copy($phpini, $phpini . '.bak');
    }
    $srcPhpIni = $supportDir . '/php.ini';
    if (file_exists($srcPhpIni) && $phpini) {
        copy($srcPhpIni, $phpini);
    }
    kirim('✅ php.ini diupdate', false, 53);

    // ── STEP 9: Buat direktori sistem ─────────────────────────────────────────
    kirim('📁 Membuat direktori sistem...', false, 54);
    $dirs = ['/home/root','/home/pma','/home/www','/home/datauser',
             '/home/xcodehoster','/home/datapengguna','/home/domain',
             '/home/checkdata','/home/checkdata2','/home/filemanager',
             '/home/server','/home/recovery','/etc/apache2/ssl'];
    foreach ($dirs as $d) {
        if (!is_dir($d)) mkdir($d, 0755, true);
    }
    kirim('✅ Direktori sistem dibuat', false, 57);

    // ── STEP 10: Copy filemanager ─────────────────────────────────────────────
    kirim('📁 Copy filemanager ke /home/filemanager...', false, 58);
    jalankan("cp -r $fmDir/* /home/filemanager/");
    kirim('✅ Filemanager disalin', false, 60);

    // ── STEP 11: Update support files (domain, password, SSL) ─────────────────
    kirim("⚙️  Update support files dengan domain: $domain...", false, 61);
    $supportFiles = glob($supportDir . '/*');
    foreach ($supportFiles as $file) {
        if (!is_file($file)) continue;
        $isi = file_get_contents($file);
        $isi = str_replace('xcodehoster.com.pem', "$domain.pem", $isi);
        $isi = str_replace('xcodehoster.com.key', "$domain.key", $isi);
        $isi = str_replace('xcodehoster.com',     $domain,       $isi);
        $isi = str_replace('sample.xcodehoster.com', $domain,    $isi);
        file_put_contents($file, $isi);
    }
    // Update domain.conf jika ada
    $domainConf2 = '/home/xcodehoster/domain.conf';
    if (file_exists($domainConf2)) {
        $isi = file_get_contents($domainConf2);
        $isi = str_replace('sample.' . $domain, $domain, $isi);
        file_put_contents($domainConf2, $isi);
    }
    kirim('✅ Support files diupdate', false, 64);

    // ── STEP 12: Copy files ke /home/xcodehoster & /var/www/html ─────────────
    kirim('📁 Copy files ke /home/xcodehoster dan /var/www/html...', false, 65);
    $copyTargets = [
        "$supportDir/support.txt"           => '/home/xcodehoster/support.txt',
        "$supportDir/index.html"            => '/var/www/html/index.html',
        "$supportDir/bootstrap.min.css"     => '/var/www/html/bootstrap.min.css',
        "$supportDir/hosting.jpg"           => '/var/www/html/hosting.jpg',
        "$supportDir/coverxcodehoster.png"  => '/var/www/html/coverxcodehoster.png',
        "$supportDir/xcodehoster21x.png"    => '/var/www/html/xcodehoster21x.png',
        "$supportDir/domain.conf"           => '/home/xcodehoster/domain.conf',
        "$supportDir/subdomain.conf"        => '/home/xcodehoster/subdomain.conf',
        "$supportDir/domain2.conf"          => '/home/xcodehoster/domain2.conf',
        "$supportDir/apache2.conf"          => '/home/xcodehoster/apache2.conf',
    ];
    foreach ($copyTargets as $src => $dst) {
        if (file_exists($src)) copy($src, $dst);
    }
    kirim('✅ Files disalin', false, 68);

    // ── STEP 13: Copy CGI files & buat acak.txt ───────────────────────────────
    kirim('⚙️  Copy CGI files ke /usr/lib/cgi-bin...', false, 69);
    $cgiFiles = ['run.cgi','formdata.cgi','aktivasi3.cgi'];
    foreach ($cgiFiles as $cgi) {
        $src = $supportDir . '/' . $cgi;
        $dst = '/usr/lib/cgi-bin/' . $cgi;
        if (file_exists($src)) {
            copy($src, $dst);
            chmod($dst, 0755);
        }
    }
    // acak.txt
    $acak = bin2hex(random_bytes(16));
    file_put_contents('/usr/lib/cgi-bin/acak.txt', $acak);
    file_put_contents('/usr/lib/cgi-bin/ip.txt', $ipserver . "\n");
    kirim('✅ CGI files disalin, acak.txt & ip.txt dibuat', false, 72);

    // ── STEP 14: SSL ──────────────────────────────────────────────────────────
    $pemFile = "/etc/apache2/ssl/$domain.pem";
    $keyFile = "/etc/apache2/ssl/$domain.key";

    if (!empty($sslpem) && !empty($sslkey)) {
        // Pakai Cloudflare Origin Certificate yang dipaste user
        kirim("🔒 Menyimpan Cloudflare Origin Certificate untuk $domain...", false, 73);
        file_put_contents($pemFile, $sslpem);
        file_put_contents($keyFile, $sslkey);
        chmod($pemFile, 0644);
        chmod($keyFile, 0644);
        kirim('✅ Cloudflare Origin Certificate disimpan', false, 76);
    } else {
        // Generate SSL self-signed otomatis
        kirim("🔒 Generate SSL self-signed untuk $domain...", false, 73);
        jalankan("openssl req -x509 -nodes -days 3650 -newkey rsa:2048 -keyout $keyFile -out $pemFile -subj '/CN=$domain' -addext 'basicConstraints=CA:FALSE' 2>/dev/null");
        kirim('✅ SSL self-signed dibuat', false, 76);
    }

    // ── STEP 15: VirtualHost config ───────────────────────────────────────────
    kirim("⚙️  Membuat VirtualHost config untuk $domain...", false, 77);
    $vhostConf = "/etc/apache2/sites-available/$domain.conf";
    $vhostContent = "<VirtualHost *:80>
    ServerName $domain
    ServerAlias www.$domain
    DocumentRoot /home/www
    <Directory /home/www>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>

<VirtualHost *:443>
    ServerName $domain
    ServerAlias www.$domain
    DocumentRoot /home/www
    SSLEngine on
    SSLCertificateFile $pemFile
    SSLCertificateKeyFile $keyFile
    <Directory /home/www>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>";
    file_put_contents($vhostConf, $vhostContent);
    jalankan("a2ensite $domain.conf");
    kirim("✅ VirtualHost $domain.conf dibuat & diaktifkan", false, 80);

    // ── STEP 16: Update aktivasi3.cgi dengan Cloudflare ──────────────────────
    kirim('☁️  Update konfigurasi Cloudflare ke aktivasi3.cgi...', false, 81);
    $aktivasiPath = '/usr/lib/cgi-bin/aktivasi3.cgi';
    if (file_exists($aktivasiPath)) {
        $isi = file_get_contents($aktivasiPath);
        $isi = str_replace('zoneid',       $zoneid,       $isi);
        $isi = str_replace('email',        $email,        $isi);
        $isi = str_replace('globalapikey', $globalapikey, $isi);
        file_put_contents($aktivasiPath, $isi);
        chmod($aktivasiPath, 0755);
    }
    // Update run.cgi juga
    $runPath = '/usr/lib/cgi-bin/run.cgi';
    if (file_exists($runPath)) {
        $isi = file_get_contents($runPath);
        $isi = str_replace('zoneid',       $zoneid,       $isi);
        $isi = str_replace('email',        $email,        $isi);
        $isi = str_replace('globalapikey', $globalapikey, $isi);
        file_put_contents($runPath, $isi);
    }
    kirim('✅ Konfigurasi Cloudflare disimpan', false, 84);

    // Fix MySQL auth untuk phpMyAdmin
    kirim('🔐 Fix autentikasi MySQL untuk phpMyAdmin...', false, 85);
    jalankan("mysql -uroot -p$passwordmysql -e \"ALTER USER 'phpmyadmin'@'localhost' IDENTIFIED WITH mysql_native_password BY '';\" 2>/dev/null");
    jalankan("mysql -uroot -p$passwordmysql -e \"ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '$passwordmysql';\" 2>/dev/null");
    jalankan("mysql -uroot -p$passwordmysql -e \"FLUSH PRIVILEGES;\" 2>/dev/null");
    kirim('✅ MySQL auth fix selesai', false, 87);

    // ── STEP 17: Generate voucher ─────────────────────────────────────────────
    kirim('🎟️  Generate 1000 kode voucher...', false, 88);
    $vouchers = [];
    for ($i = 0; $i < 1000; $i++) {
        $vouchers[] = strtoupper(bin2hex(random_bytes(4)));
    }
    $voucherStr = implode("\n", $vouchers) . "\n";
    $voucherFile = '/usr/lib/cgi-bin/vouchers.txt';
    file_put_contents($voucherFile, $voucherStr);
    $voucherCopy = '/home/xcodehoster/vouchers' . rand(100,999) . '.txt';
    file_put_contents($voucherCopy, $voucherStr);
    kirim('✅ 1000 voucher dibuat', false, 91);

    // ── STEP 18: Apache config check & restart ────────────────────────────────
    kirim('🔄 Apache syntax check & restart...', false, 92);
    $apacheTest = jalankan('apache2ctl configtest 2>&1');
    if (strpos($apacheTest, 'Syntax OK') !== false) {
        kirim('✅ Apache config: Syntax OK', false, 94);
    } else {
        kirim('⚠️  Apache config warning: ' . $apacheTest, false, 94);
    }
    jalankan('service apache2 restart');
    kirim('✅ Apache berhasil direstart', false, 96);

    // ── STEP 19: Simpan .env ──────────────────────────────────────────────────
    $envContent = "APP_VERSION=11\nSERVER_IP=$ipserver\nMAIN_DOMAIN=$domain\nDB_PASS=$passwordmysql\nCF_ZONE_ID=$zoneid\nCF_EMAIL=$email\nCF_API_KEY=$globalapikey\nSSL_PEM=$pemFile\nSSL_KEY=$keyFile\nINSTALLED=" . date('Y-m-d H:i:s') . "\n";
    file_put_contents($installDir . '/.env', $envContent);
    kirim('✅ File .env disimpan', false, 98);

    // ── SELESAI ───────────────────────────────────────────────────────────────
    $result = [
        'website'    => "https://$domain",
        'formdata'   => "https://$domain/cgi-bin/formdata.cgi",
        'phpmyadmin' => "http://$ipserver/phpmyadmin",
        'voucher'    => basename($voucherCopy),
        'domain'     => $domain,
        'ip'         => $ipserver,
    ];
    kirim('🎉 INSTALASI XCODEHOSTER V11 SELESAI!', true, 100, $result);

    unset($_SESSION['install_data']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Xcodehoster v11 — Web Installer</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Sora:wght@300;400;600;700&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg: #0a0e1a;
    --surface: #111827;
    --border: #1e2d40;
    --accent: #00d4ff;
    --accent2: #7c3aed;
    --success: #10b981;
    --warn: #f59e0b;
    --error: #ef4444;
    --text: #e2e8f0;
    --muted: #64748b;
  }

  body {
    font-family: 'Sora', sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
    background-image:
      radial-gradient(ellipse at 20% 20%, rgba(0,212,255,0.06) 0%, transparent 60%),
      radial-gradient(ellipse at 80% 80%, rgba(124,58,237,0.06) 0%, transparent 60%);
  }

  .container {
    width: 100%;
    max-width: 680px;
  }

  /* Header */
  .header {
    text-align: center;
    margin-bottom: 32px;
  }
  .logo {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 12px;
  }
  .logo-icon {
    width: 44px; height: 44px;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    border-radius: 12px;
    display: flex; align-items: center; justify-content: center;
    font-size: 22px;
  }
  .logo-text {
    font-size: 22px; font-weight: 700;
    background: linear-gradient(90deg, var(--accent), var(--accent2));
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    letter-spacing: -0.5px;
  }
  .header p {
    color: var(--muted); font-size: 13px;
    font-family: 'JetBrains Mono', monospace;
  }

  /* Card */
  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 16px;
    overflow: hidden;
  }

  /* Steps nav */
  .steps {
    display: flex;
    border-bottom: 1px solid var(--border);
    padding: 0 24px;
  }
  .step-tab {
    flex: 1; text-align: center;
    padding: 16px 8px;
    font-size: 12px; font-weight: 600;
    color: var(--muted);
    border-bottom: 2px solid transparent;
    transition: all .2s;
    letter-spacing: 0.5px;
    text-transform: uppercase;
  }
  .step-tab.active {
    color: var(--accent);
    border-bottom-color: var(--accent);
  }
  .step-tab.done {
    color: var(--success);
  }

  /* Panels */
  .panel { display: none; padding: 28px 28px 32px; }
  .panel.active { display: block; }

  /* Check panel */
  .check-item {
    display: flex; align-items: center; gap: 12px;
    padding: 12px 16px;
    background: rgba(255,255,255,0.03);
    border: 1px solid var(--border);
    border-radius: 10px;
    margin-bottom: 10px;
    font-size: 13px;
  }
  .check-icon { font-size: 18px; width: 24px; text-align: center; }
  .check-label { flex: 1; color: var(--muted); }
  .check-val { font-family: 'JetBrains Mono', monospace; font-size: 12px; }
  .check-val.ok { color: var(--success); }
  .check-val.fail { color: var(--error); }

  /* Form */
  .section-title {
    font-size: 11px; font-weight: 600; letter-spacing: 1px;
    text-transform: uppercase; color: var(--muted);
    margin: 20px 0 12px;
  }
  .section-title:first-child { margin-top: 0; }

  .field { margin-bottom: 14px; }
  .field label {
    display: block; font-size: 12px; font-weight: 600;
    color: var(--muted); margin-bottom: 6px;
    text-transform: uppercase; letter-spacing: 0.5px;
  }
  .field input {
    width: 100%;
    background: rgba(255,255,255,0.04);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 10px 14px;
    color: var(--text);
    font-family: 'JetBrains Mono', monospace;
    font-size: 13px;
    outline: none;
    transition: border-color .2s, background .2s;
  }
  .field input:focus {
    border-color: var(--accent);
    background: rgba(0,212,255,0.04);
  }
  .field input::placeholder { color: var(--muted); }
  .field-hint {
    font-size: 11px; color: var(--muted);
    margin-top: 4px; font-family: 'JetBrains Mono', monospace;
  }

  /* Progress */
  .progress-bar-wrap {
    background: rgba(255,255,255,0.05);
    border-radius: 100px;
    height: 6px;
    margin-bottom: 20px;
    overflow: hidden;
  }
  .progress-bar {
    height: 100%;
    background: linear-gradient(90deg, var(--accent), var(--accent2));
    border-radius: 100px;
    width: 0%;
    transition: width .4s ease;
  }

  .log-box {
    background: #060a12;
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 16px;
    height: 300px;
    overflow-y: auto;
    font-family: 'JetBrains Mono', monospace;
    font-size: 12px;
    line-height: 1.8;
  }
  .log-line { display: block; }
  .log-line.ok { color: var(--success); }
  .log-line.err { color: var(--error); }
  .log-line.warn { color: var(--warn); }
  .log-line.info { color: var(--muted); }

  /* Result */
  .result-box {
    background: rgba(16,185,129,0.07);
    border: 1px solid rgba(16,185,129,0.25);
    border-radius: 12px;
    padding: 20px;
    margin-top: 20px;
  }
  .result-box h3 {
    color: var(--success); font-size: 15px; margin-bottom: 14px;
  }
  .result-item {
    display: flex; gap: 10px; align-items: center;
    padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.05);
    font-size: 12px;
  }
  .result-item:last-child { border-bottom: none; }
  .result-item .ri-label { color: var(--muted); width: 130px; flex-shrink: 0; }
  .result-item a { color: var(--accent); text-decoration: none; font-family: 'JetBrains Mono', monospace; word-break: break-all; }
  .result-item a:hover { text-decoration: underline; }
  .result-item span { font-family: 'JetBrains Mono', monospace; color: var(--text); }

  /* Buttons */
  .btn {
    display: inline-flex; align-items: center; gap: 8px;
    padding: 11px 22px; border-radius: 8px; font-size: 13px;
    font-weight: 600; font-family: 'Sora', sans-serif;
    cursor: pointer; border: none; transition: all .2s;
    letter-spacing: 0.3px;
  }
  .btn-primary {
    background: linear-gradient(135deg, var(--accent), #0099bb);
    color: #000;
  }
  .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
  .btn-primary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }
  .btn-secondary {
    background: transparent;
    color: var(--muted);
    border: 1px solid var(--border);
  }
  .btn-secondary:hover { color: var(--text); border-color: var(--muted); }

  .btn-row { display: flex; justify-content: flex-end; gap: 10px; margin-top: 24px; }

  .alert {
    padding: 12px 16px; border-radius: 8px;
    font-size: 13px; margin-bottom: 16px;
  }
  .alert-error { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); color: #fca5a5; }
  .alert-warn  { background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.3); color: #fcd34d; }

  .spinner {
    width: 16px; height: 16px;
    border: 2px solid rgba(0,0,0,0.3);
    border-top-color: #000;
    border-radius: 50%;
    animation: spin .7s linear infinite;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
</style>
</head>
<body>
<div class="container">

  <div class="header">
    <div class="logo">
      <div class="logo-icon">🚀</div>
      <div class="logo-text">Xcodehoster v11</div>
    </div>
    <p>Web Installer · xcode.or.id</p>
  </div>

  <div class="card">
    <div class="steps">
      <div class="step-tab active" id="tab1">① Cek Sistem</div>
      <div class="step-tab" id="tab2">② Konfigurasi</div>
      <div class="step-tab" id="tab3">③ Instalasi</div>
    </div>

    <!-- PANEL 1: CEK SISTEM -->
    <div class="panel active" id="panel1">
      <div id="check-items">
        <div class="check-item">
          <span class="check-icon">💻</span>
          <span class="check-label">Sistem Operasi</span>
          <span class="check-val" id="chk-os">Mengecek...</span>
        </div>
        <div class="check-item">
          <span class="check-icon">🔐</span>
          <span class="check-label">Hak Akses Root</span>
          <span class="check-val" id="chk-root">Mengecek...</span>
        </div>
        <div class="check-item">
          <span class="check-icon">📁</span>
          <span class="check-label">Folder support/</span>
          <span class="check-val" id="chk-support">Mengecek...</span>
        </div>
      </div>
      <div id="check-alert" style="margin-top:16px;display:none;"></div>
      <div class="btn-row">
        <button class="btn btn-secondary" onclick="runCheck()">🔄 Cek Ulang</button>
        <button class="btn btn-primary" id="btn-next1" disabled onclick="goPanel(2)">Lanjut →</button>
      </div>
    </div>

    <!-- PANEL 2: FORM KONFIGURASI -->
    <div class="panel" id="panel2">
      <div id="form-alert" style="display:none;"></div>

      <div class="section-title">🖥️ Konfigurasi Server</div>
      <div class="field">
        <label>IP Publik Server</label>
        <input type="text" id="f-ip" placeholder="">
      </div>
      <div class="field">
        <label>Password MySQL Root</label>
        <input type="password" id="f-pass" placeholder="">
        <div class="field-hint">Minimum 8 karakter. Simpan baik-baik.</div>
      </div>
      <div class="field">
        <label>Nama Domain</label>
        <input type="text" id="f-domain" placeholder="">
        <div class="field-hint">Tanpa http:// dan tanpa www</div>
      </div>

      <div class="section-title">☁️ Konfigurasi Cloudflare</div>
      <div class="field">
        <label>Zone ID</label>
        <input type="text" id="f-zoneid" placeholder="">
      </div>
      <div class="field">
        <label>Email Cloudflare</label>
        <input type="email" id="f-email" placeholder="">
      </div>
      <div class="field">
        <label>Global API Key</label>
        <input type="password" id="f-apikey" placeholder="">
        <div class="field-hint">My Profile → API Tokens → Global API Key → View</div>
      </div>

      <div class="section-title">🔒 SSL Certificate (Cloudflare Origin)</div>
      <div class="field">
        <label>Certificate PEM</label>
        <textarea id="f-pem" rows="5" placeholder="-----BEGIN CERTIFICATE-----
(paste Cloudflare Origin Certificate di sini)
-----END CERTIFICATE-----" style="width:100%;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:8px;padding:10px 14px;color:var(--text);font-family:'JetBrains Mono',monospace;font-size:12px;outline:none;resize:vertical;transition:border-color .2s;"></textarea>
        <div class="field-hint">Opsional. Kosongkan jika pakai SSL self-signed otomatis.</div>
      </div>
      <div class="field">
        <label>Private Key</label>
        <textarea id="f-key" rows="5" placeholder="-----BEGIN PRIVATE KEY-----
(paste Private Key di sini)
-----END PRIVATE KEY-----" style="width:100%;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:8px;padding:10px 14px;color:var(--text);font-family:'JetBrains Mono',monospace;font-size:12px;outline:none;resize:vertical;transition:border-color .2s;"></textarea>
        <div class="field-hint">Opsional. Kosongkan jika pakai SSL self-signed otomatis.</div>
      </div>

      <div class="btn-row">
        <button class="btn btn-secondary" onclick="goPanel(1)">← Kembali</button>
        <button class="btn btn-primary" id="btn-install" onclick="startInstall()">🚀 Mulai Instalasi</button>
      </div>
    </div>

    <!-- PANEL 3: PROSES INSTALASI -->
    <div class="panel" id="panel3">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <span style="font-size:13px;font-weight:600;" id="pct-label">Mempersiapkan...</span>
        <span style="font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--accent);" id="pct-num">0%</span>
      </div>
      <div class="progress-bar-wrap">
        <div class="progress-bar" id="progress-bar"></div>
      </div>

      <div class="log-box" id="log-box"></div>

      <div id="result-box" style="display:none;"></div>

      <div class="btn-row" id="btn-done-row" style="display:none;">
        <button class="btn btn-primary" onclick="window.location.reload()">🔄 Instalasi Baru</button>
      </div>
    </div>
  </div>

</div>

<script>
let currentPanel = 1;

function goPanel(n) {
  document.getElementById('panel' + currentPanel).classList.remove('active');
  document.getElementById('tab' + currentPanel).classList.remove('active');
  currentPanel = n;
  document.getElementById('panel' + n).classList.add('active');
  document.getElementById('tab' + n).classList.add('active');
}

// ── CEK SISTEM ────────────────────────────────────────────────────────────────
async function runCheck() {
  document.getElementById('chk-os').textContent = 'Mengecek...';
  document.getElementById('chk-root').textContent = 'Mengecek...';
  document.getElementById('chk-support').textContent = 'Mengecek...';
  document.getElementById('btn-next1').disabled = true;
  document.getElementById('check-alert').style.display = 'none';

  const fd = new FormData();
  fd.append('action','check');
  const res = await fetch('', {method:'POST', body: fd});
  const d = await res.json();

  const setChk = (id, ok, label) => {
    const el = document.getElementById(id);
    el.textContent = label;
    el.className = 'check-val ' + (ok ? 'ok' : 'fail');
  };

  setChk('chk-os',      d.os === '24.04', d.os ? 'Ubuntu ' + d.os : 'Tidak terdeteksi');
  setChk('chk-root',    d.isRoot,  d.isRoot  ? 'Siap ✓' : 'Tidak tersedia ✗');
  setChk('chk-support', d.support, d.support ? 'Ditemukan ✓' : 'Tidak ada ✗');

  if (d.ok) {
    document.getElementById('btn-next1').disabled = false;
  } else {
    const al = document.getElementById('check-alert');
    al.style.display = 'block';
    let msg = '';
    if (d.os !== '24.04') msg += '• Harus Ubuntu 24.04<br>';
    if (!d.support) msg += '• Folder support/ tidak ditemukan. Pastikan install_web.php ada di dalam folder xcodehosterv11/<br>';
    al.innerHTML = '<div class="alert alert-error">' + msg + '</div>';
  }
}

// ── START INSTALL ─────────────────────────────────────────────────────────────
async function startInstall() {
  const ip     = document.getElementById('f-ip').value.trim();
  const pass   = document.getElementById('f-pass').value.trim();
  const domain = document.getElementById('f-domain').value.trim();
  const zoneid = document.getElementById('f-zoneid').value.trim();
  const email  = document.getElementById('f-email').value.trim();
  const apikey = document.getElementById('f-apikey').value.trim();
  const pem    = document.getElementById('f-pem').value.trim();
  const key    = document.getElementById('f-key').value.trim();

  const al = document.getElementById('form-alert');

  if (!ip || !pass || !domain || !zoneid || !email || !apikey) {
    al.style.display = 'block';
    al.innerHTML = '<div class="alert alert-error">Semua field wajib diisi.</div>';
    return;
  }
  if (pass.length < 8) {
    al.style.display = 'block';
    al.innerHTML = '<div class="alert alert-error">Password minimal 8 karakter.</div>';
    return;
  }

  al.style.display = 'none';

  const fd = new FormData();
  fd.append('action',        'install');
  fd.append('ipserver',      ip);
  fd.append('passwordmysql', pass);
  fd.append('domain',        domain);
  fd.append('zoneid',        zoneid);
  fd.append('email',         email);
  fd.append('globalapikey',  apikey);
  fd.append('sslpem',        pem);
  fd.append('sslkey',        key);

  const res = await fetch('', {method:'POST', body: fd});
  const d   = await res.json();

  if (!d.success) {
    al.style.display = 'block';
    al.innerHTML = '<div class="alert alert-error">' + d.message + '</div>';
    return;
  }

  goPanel(3);
  streamInstall();
}

// ── STREAMING LOG ─────────────────────────────────────────────────────────────
function streamInstall() {
  const logBox  = document.getElementById('log-box');
  const bar     = document.getElementById('progress-bar');
  const pctNum  = document.getElementById('pct-num');
  const pctLbl  = document.getElementById('pct-label');

  const src = new EventSource('?stream=1');

  src.onmessage = function(e) {
    const data = JSON.parse(e.data);

    // Log line
    const line = document.createElement('span');
    line.className = 'log-line ' + getLineClass(data.log);
    line.textContent = data.log;
    logBox.appendChild(line);
    logBox.appendChild(document.createElement('br'));
    logBox.scrollTop = logBox.scrollHeight;

    // Progress
    if (data.pct) {
      bar.style.width = data.pct + '%';
      pctNum.textContent = data.pct + '%';
      pctLbl.textContent = data.log;
    }

    // Done
    if (data.done) {
      src.close();
      pctLbl.textContent = '✅ Instalasi selesai!';
      document.getElementById('btn-done-row').style.display = 'flex';

      if (data.result) {
        showResult(data.result);
      }
    }
  };

  src.onerror = function() {
    src.close();
    const line = document.createElement('span');
    line.className = 'log-line err';
    line.textContent = '❌ Koneksi terputus. Cek kembali status instalasi.';
    logBox.appendChild(line);
    logBox.scrollTop = logBox.scrollHeight;
  };
}

function getLineClass(msg) {
  if (msg.startsWith('✅')) return 'ok';
  if (msg.startsWith('❌')) return 'err';
  if (msg.startsWith('⚠️')) return 'warn';
  if (msg.startsWith('🎉')) return 'ok';
  return 'info';
}

function showResult(r) {
  const box = document.getElementById('result-box');
  box.style.display = 'block';
  box.innerHTML = `
    <div class="result-box">
      <h3>🎉 Instalasi Berhasil!</h3>
      <div class="result-item">
        <span class="ri-label">Website Utama</span>
        <a href="${r.website}" target="_blank">${r.website}</a>
      </div>
      <div class="result-item">
        <span class="ri-label">Form Pendaftaran</span>
        <a href="${r.formdata}" target="_blank">${r.formdata}</a>
      </div>
      <div class="result-item">
        <span class="ri-label">phpMyAdmin</span>
        <a href="${r.phpmyadmin}" target="_blank">${r.phpmyadmin}</a>
      </div>
      <div class="result-item">
        <span class="ri-label">File Voucher</span>
        <span>${r.voucher}</span>
      </div>
      <div class="result-item" style="margin-top:8px;padding-top:12px;border-top:1px solid rgba(255,255,255,0.07);">
        <span class="ri-label" style="color:#fcd34d;">Langkah Berikutnya</span>
        <span style="color:#fcd34d;font-size:11px;">Arahkan DNS domain ke IP ${r.ip} via Cloudflare (SSL Flexible)</span>
      </div>
    </div>`;
}

// Auto-run check saat halaman load
window.addEventListener('DOMContentLoaded', runCheck);
</script>
</body>
</html>
